"""
client.py — the nullroom terminal client for Kali Linux.

Full-screen TUI, standard library only, no pip install, no ncurses.
Connects to any nullroom server over ws:// or wss://.

Features (16):
   1. Room browser            — live list of every public room, with people counts
   2. Full-screen TUI         — ANSI-drawn panes, 256 colours, resize-safe
   3. Live chat               — real-time broadcast with typing indicators
   4. Anonymous identity      — random handle, regenerable, per session only
   5. Direct messages         — private 1:1 tabs between handles in a room
   6. Room creation           — make a room and set its topic
   7. Mentions and highlights — your handle lights up, plus sound/beep
   8. Local scrollback        — scroll history, search it, export it
   9. Slash commands          — a small command language for everything
  10. Server profiles         — save servers, switch with one command
  11. Latency and link stats  — ping/pong round trip and connection health
  12. Theme switching         — dark, light, and high-contrast palettes
  13. Desktop notification    — notify-send on mention when unfocused
  14. URL detection           — links are highlighted and openable
  15. Transcript export       — write the session to a file, on demand
  16. Graceful degradation    — works over SSH, in tmux, on a dumb terminal

Usage:
    python3 client.py                       # connect to the default server
    python3 client.py --server host:port    # a specific server
    python3 client.py --room kali           # join a room immediately
    python3 client.py --server wss://host   # TLS
"""

import argparse
import json
import os
import re
import select
import shutil
import socket
import ssl
import subprocess
import sys
import threading
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tui import (  # noqa: E402
    UI, fg, bg, BOLD, DIM, ITALIC, RESET, C_ACCENT, C_ACCENT2, C_BG, C_DIM,
    C_ERR, C_PANEL, C_SYS, C_TEXT, C_WARN, display_width, truncate, wrap,
)

VERSION = "1.0.0"
CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".config", "nullroom")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
DEFAULT_SERVER = "ws://127.0.0.1:8080"

THEMES = {
    "dark": {"accent": 79, "accent2": 141, "text": 252, "dim": 245, "err": 203},
    "light": {"accent": 30, "accent2": 91, "text": 235, "dim": 243, "err": 160},
    "contrast": {"accent": 51, "accent2": 226, "text": 231, "dim": 250, "err": 196},
}

URL_RE = re.compile(r"https?://[^\s<>\"']+|www\.[^\s<>\"']+")
ADJ = ["quiet", "loud", "slow", "fast", "grey", "amber", "violet", "hollow",
       "bitter", "gentle", "sharp", "wandering", "static", "distant", "ashen",
       "paper", "iron", "salt", "neon", "pale"]
NOUN = ["fox", "crow", "moth", "heron", "otter", "wren", "lynx", "hare",
        "raven", "koi", "ibis", "seal", "stork", "newt", "finch", "puma"]

# Room IDs are short, readable, and unambiguous: no 0/O/1/I/L.
ID_ALPHABET = "23456789abcdefghjkmnpqrstuvwxyz"
ID_LENGTH = 6
ROOM_ID_RE = re.compile(r"^[%s]{%d}$" % (ID_ALPHABET, ID_LENGTH))


def make_room_id():
    import random
    return "".join(random.choice(ID_ALPHABET) for _ in range(ID_LENGTH))


def random_handle():
    import random
    return "%s-%s-%d" % (random.choice(ADJ), random.choice(NOUN),
                         random.randint(10, 99))


# ── config ──────────────────────────────────────────────────────────────

def load_config():
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def save_config(cfg):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        tmp = CONFIG_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(cfg, fh, indent=2)
        os.replace(tmp, CONFIG_FILE)
    except OSError:
        pass


# ── websocket client ────────────────────────────────────────────────────

class WSClient:
    """Minimal RFC6455 client. One reader thread pushes frames to a queue."""

    def __init__(self, url, on_open=None, on_message=None, on_close=None,
                 on_error=None):
        self.url = url
        self._buf = b""
        self.on_open = on_open
        self.on_message = on_message
        self.on_close = on_close
        self.on_error = on_error
        self.sock = None
        self.alive = False
        self.thread = None
        self._send_lock = threading.Lock()
        self.latency = None
        self.last_ping = 0.0
        self.last_pong = 0.0

    def connect(self):
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def _run(self):
        try:
            scheme, host, port, path = parse_ws_url(self.url)
            raw = socket.create_connection((host, port), timeout=12)
            if scheme == "wss":
                ctx = ssl.create_default_context()
                raw = ctx.wrap_socket(raw, server_hostname=host)
            raw.settimeout(None)
            self.sock = raw
            self._handshake(host, port, path)
            self.alive = True
            if self.on_open:
                self.on_open()
            self._read_loop()
        except Exception as exc:
            if self.on_error:
                self.on_error(str(exc))
        finally:
            self.alive = False
            try:
                if self.sock:
                    self.sock.close()
            except OSError:
                pass
            if self.on_close:
                self.on_close()

    def switch_room(self, room=None, room_id=None, key=None):
        """Point this client at another room on the same server. Rooms are
        separate connections, so this is a clean reconnect, not a message.

        Pass room_id to join by id, and key for a locked room.
        """
        scheme, host, port, _ = parse_ws_url(self.url)
        base = "%s://%s:%d" % (scheme, host, port)
        path = "/" + (room or "lobby").lstrip("#")
        params = []
        if room_id:
            params.append("id=" + str(room_id))
        if key:
            params.append("key=" + str(key))
        if params:
            path += "?" + "&".join(params)
        self.url = base + path
        self.close()

    def _handshake(self, host, port, path):
        import base64
        key = base64.b64encode(os.urandom(16)).decode()
        req = (
            "GET %s HTTP/1.1\r\nHost: %s:%d\r\nUpgrade: websocket\r\n"
            "Connection: Upgrade\r\nSec-WebSocket-Key: %s\r\n"
            "Sec-WebSocket-Version: 13\r\n"
            "User-Agent: nullroom-tui/%s\r\n\r\n" % (path, host, port, key, VERSION)
        )
        self.sock.sendall(req.encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise IOError("server closed during handshake")
            buf += chunk
            if len(buf) > 65536:
                raise IOError("handshake too large")
        head, _, rest = buf.partition(b"\r\n\r\n")
        status_line = head.split(b"\r\n")[0].decode("latin-1", "replace")
        if "101" not in status_line:
            raise IOError("handshake refused: " + status_line.strip())
        self._buf = rest

    def _recv_exact(self, n):
        while len(self._buf) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise IOError("connection closed")
            self._buf += chunk
        out, self._buf = self._buf[:n], self._buf[n:]
        return out

    def _read_loop(self):
        while self.alive:
            b1, b2 = self._recv_exact(2)
            opcode = b1 & 0x0F
            length = b2 & 0x7F
            if length == 126:
                length = int.from_bytes(self._recv_exact(2), "big")
            elif length == 127:
                length = int.from_bytes(self._recv_exact(8), "big")
            payload = self._recv_exact(length) if length else b""
            if opcode == 0x8:          # close
                raise IOError("server closed the connection")
            if opcode == 0x9:          # ping
                self._send_frame(0xA, payload)
                continue
            if opcode == 0xA:          # pong
                self.last_pong = time.time()
                if self.last_ping:
                    self.latency = int((self.last_pong - self.last_ping) * 1000)
                continue
            if opcode in (0x1, 0x2):
                try:
                    text = payload.decode("utf-8")
                except UnicodeDecodeError:
                    continue
                if self.on_message:
                    self.on_message(text)

    def _send_frame(self, opcode, payload=b""):
        import struct
        header = bytearray()
        header.append(0x80 | opcode)
        n = len(payload)
        if n < 126:
            header.append(0x80 | n)
        elif n < (1 << 16):
            header.append(0x80 | 126)
            header += struct.pack("!H", n)
        else:
            header.append(0x80 | 127)
            header += struct.pack("!Q", n)
        mask = os.urandom(4)
        masked = bytes(b ^ mask[i & 3] for i, b in enumerate(payload))
        with self._send_lock:
            if not self.sock:
                raise IOError("not connected")
            self.sock.sendall(bytes(header) + mask + masked)

    def send(self, obj):
        try:
            self._send_frame(0x1, json.dumps(obj).encode("utf-8"))
            return True
        except Exception:
            return False

    def ping(self):
        self.last_ping = time.time()
        try:
            self._send_frame(0x9, os.urandom(4))
        except Exception:
            pass

    def close(self):
        if not self.alive:
            return
        self.alive = False
        try:
            self._send_frame(0x8, b"\x03\xe8")
        except Exception:
            pass
        try:
            if self.sock:
                self.sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass


def parse_invite(text):
    """Parse an invite string into (server, room, room_id, key).

    Accepts any of:
        chat.example.com/kali?id=k6bb4h
        ws://chat.example.com:8080/kali?id=k6bb4h&key=secret
        nullroom --invite chat.example.com/kali?id=k6bb4h
        127.0.0.1:8080/room-abc123
    """
    text = (text or "").strip()
    if text.startswith("nullroom"):
        text = text.split("--invite", 1)[-1].strip()
    text = text.split("\n")[0].strip()
    if "://" in text:
        scheme, rest = text.split("://", 1)
    else:
        scheme, rest = "ws", text
    frag = ""
    if "?" in rest:
        rest, frag = rest.split("?", 1)
    params = {}
    for pair in frag.split("&"):
        if "=" in pair:
            k, v = pair.split("=", 1)
            params[k.strip()] = v.strip()
    if "/" in rest:
        hostport, room = rest.split("/", 1)
        room = room.strip("/")
    else:
        hostport, room = rest, "lobby"
    if ":" in hostport and not hostport.count(":") > 1:
        host, port_s = hostport.rsplit(":", 1)
        port = int(port_s)
        server = "%s://%s:%d" % (scheme, host, port)
    else:
        server = "%s://%s" % (scheme, hostport)
    room_id = params.get("id") or (room if ROOM_ID_RE.match(room.lower()) else None)
    if room_id and ROOM_ID_RE.match(room.lower()):
        room = "lobby"
    key = params.get("key") or params.get("k")
    return server, room, (room_id.lower() if room_id else None), key


def parse_ws_url(url):
    """Return (scheme, host, port, path) for ws://, wss://, host:port, or host."""
    url = url.strip()
    if "://" not in url:
        url = "ws://" + url
    scheme, rest = url.split("://", 1)
    scheme = scheme.lower()
    if scheme not in ("ws", "wss"):
        scheme = "ws"
    if "/" in rest:
        hostport, path = rest.split("/", 1)
        path = "/" + path
    else:
        hostport, path = rest, "/"
    if path in ("/", "/ws"):
        # A bare server address names no room: connect to the lobby.
        path = "/ws/lobby"
    elif not path.startswith("/ws/"):
        path = "/ws" + (path if path.startswith("/") else "/" + path)
    if ":" in hostport:
        host, port_s = hostport.rsplit(":", 1)
        port = int(port_s)
    else:
        host = hostport
        port = 443 if scheme == "wss" else 80
    return scheme, host, port, path


# ── application ─────────────────────────────────────────────────────────

HELP_KEYS = [
    ("Enter", "send message"),
    ("Ctrl-N", "create a room"),
    ("Ctrl-J", "join a room"),
    ("Ctrl-I", "invite to this room"),
    ("Ctrl-X", "close this room (creator only)"),
    ("Tab", "switch room tab"),
    ("Ctrl-R", "rooms browser"),
    ("Ctrl-F", "search scrollback"),
    ("Ctrl-S", "save transcript"),
    ("Ctrl-T", "cycle theme"),
    ("Ctrl-O", "open last URL"),
    ("PgUp/Dn", "scroll"),
    ("Ctrl-L", "redraw"),
    ("Ctrl-D", "quit"),
    ("/help", "full command list"),
]


class App:
    def __init__(self, server, room=None, handle=None, theme="dark",
                 no_color=False, notify=True):
        self.ui = UI()
        self.server = server
        self.handle = handle or random_handle()
        self.theme_name = theme
        self.theme = THEMES.get(theme, THEMES["dark"])
        self.no_color = no_color
        self.notify_enabled = notify
        self.ws = None
        self.rooms = []
        self.rooms_selected = 0
        self.rooms = []
        self.view = "chat"          # chat | rooms | help | invite
        self.room = room
        self.room_topic = ""
        self.room_users = 0
        self.limits = {"max_chars": 1000}
        self.tabs = []              # ["#room", ...]
        self.tab = 0
        self.buffers = {}           # tab -> list of message dicts
        self.room_ids = {}          # "#name" -> 6-char room id
        self.room_id = None         # id of the room you are in now
        self.room_lock_key = None   # key for a locked room, if you hold it
        self.owned_rooms = {}       # "#name" -> {"id":..., "topic":...}
        self.unread = {}
        self.connected = False
        self.reconnect_delay = 1.0
        self.next_reconnect = 0.0
        self.status = "connecting…"
        self.status_colour = C_WARN
        self.typing = {}
        self.last_url = None
        self.filter_query = ""
        self.search_hits = []
        self.search_index = 0
        self.last_mention_notify = 0.0
        self.mention_sound = True
        self.last_ping = 0.0
        self.last_activity = time.time()
        self.transcript = []
        self.pending_room_creation = False
        self.pending_room_name = None
        self.invite_text = []
        self.running = True
        self.overlay = None         # ("input", prompt, callback)
        self.overlay_buf = []

    # ── lifecycle ───────────────────────────────────────────────────────
    def run(self):
        self.ui.init()
        self.ui.help_text = "  ".join(k for k, _ in HELP_KEYS[:6])
        self.connect()
        try:
            while self.running:
                self.tick()
        finally:
            self.shutdown()
        return 0

    def shutdown(self):
        self.running = False
        if self.ws:
            self.ws.close()
        self.ui.close()

    def connect(self, room_override=None, room_id=None, key=None):
        self.status = "connecting to %s…" % self.server
        self.status_colour = C_WARN
        url = self.server.rstrip("/")
        target = room_override if room_override is not None else self.room
        if target:
            url = url + "/" + target
        query = []
        if room_id:
            query.append("id=" + str(room_id))
        if key:
            query.append("key=" + str(key))
        if query:
            url = url + "?" + "&".join(query)
        # The server moves this connection into a created room, so the App
        # follows joined/room-id replies rather than assuming the URL room.
        self.ws = WSClient(url, on_open=self._on_open,
                           on_message=self._on_message, on_close=self._on_close,
                           on_error=self._on_error)
        self.ws.connect()

    def reconnect_current(self):
        if self.ws:
            try:
                self.ws.close()
            except Exception:
                pass
        self.connect()

    def _on_open(self):
        self.connected = True
        self.reconnect_delay = 1.0
        self.status = "connected"
        self.status_colour = C_ACCENT
        self.ws.send({"t": "hello", "nick": self.handle})

    def _on_error(self, message):
        self.push("err", "connection error: " + message)

    def _on_close(self):
        self.connected = False
        self.status = "disconnected — retrying"
        self.status_colour = C_ERR
        self.next_reconnect = time.time() + self.reconnect_delay
        self.reconnect_delay = min(self.reconnect_delay * 1.8, 20.0)

    def _on_message(self, raw):
        try:
            msg = json.loads(raw)
        except ValueError:
            return
        kind = msg.get("t")
        if kind == "welcome":
            self.handle = msg.get("nick", self.handle)
            self.limits = msg.get("limits", self.limits)
            if msg.get("room"):
                self.absorb_room(msg["room"])
            self.ensure_tab()
            self.push("sys", "you are %s in %s" % (self.handle, self.room_label()))
            # Room creation is confirmed by 'joined' with created=true;
            # the welcome path must not fire the invite early.
        elif kind == "joined":
            r = msg.get("room") or {}
            self.absorb_room(r)
            if msg.get("you_own_it") and r.get("name"):
                self.owned_rooms["#" + r["name"]] = {
                    "id": r.get("id"), "topic": r.get("topic", "")}
            # The server moved this connection: follow it.
            if r.get("name"):
                self.room = r["name"]
                self.room_topic = r.get("topic", "")
                if r.get("id"):
                    self.room_id = r["id"]
                    self.room_ids["#" + r["name"]] = r["id"]
            self.ensure_tab()
            if msg.get("created"):
                self.pending_room_creation = False
                self.push("sys", "room created — share it with /invite")
                self.show_invite()
        elif kind == "backlog":
            for item in msg.get("items", []):
                self.add_message(item["nick"], item["text"], item.get("ts"))
            self.push("sep", "— in-memory history above; nothing is stored on disk —")
        elif kind == "msg":
            self.add_message(msg.get("nick", "?"), msg.get("text", ""),
                             msg.get("ts"))
        elif kind == "sys":
            text = msg.get("text", "")
            self.push("join", text)
            self.track_membership(text)
        elif kind == "err":
            self.push("err", msg.get("text", "server error"))
            if msg.get("exists"):
                # The name was taken: fall back to just joining it.
                self.pending_room_creation = False
        elif kind == "room-id":
            self.room_id = msg.get("id") or self.room_id
            if msg.get("name"):
                self.room = msg["name"]
                self.room_ids["#" + msg["name"]] = self.room_id
            if msg.get("you_own_it"):
                self.owned_rooms["#" + (self.room or "")] = {
                    "id": self.room_id, "topic": self.room_topic}
            self.invite_text = self.build_invite()
            if msg.get("rotated"):
                self.push("sys", "new room id: %s — the old one is dead"
                          % self.room_id)
                self.copy_invite(silent=True)
        elif kind == "lock-state":
            if msg.get("locked"):
                self.push("sys", "room is locked")
            else:
                self.room_lock_key = None
                self.push("sys", "room is open")
            self.invite_text = self.build_invite()
        elif kind == "closed":
            name = msg.get("room") or "this room"
            self.push("err", "#%s was closed: %s" % (name, msg.get("reason", "")))
            self.unread.pop("#" + name, None)
        elif kind == "topic":
            self.room_topic = msg.get("topic", self.room_topic)
            self.push("sys", "topic: %s" % self.room_topic)
        elif kind == "typing":
            nick = msg.get("nick", "?")
            if nick != self.handle:
                self.typing[nick] = time.time()
        elif kind == "pong":
            if self.last_ping:
                self.ws.latency = int((time.time() - self.last_ping) * 1000)

    # ── data helpers ────────────────────────────────────────────────────
    def absorb_room(self, r):
        """Take a room dict from the server and remember its name, topic,
        headcount, id and lifetime."""
        if not r:
            return
        self.room = r.get("name", self.room)
        self.room_topic = r.get("topic", "")
        self.room_users = r.get("users", 0)
        if r.get("id"):
            self.room_id = r["id"]
            self.room_ids["#" + (self.room or "")] = r["id"]
            if r.get("owner") == self.handle:
                self.owned_rooms["#" + (self.room or "")] = {
                    "id": r["id"], "topic": self.room_topic,
                }

    def ensure_tab(self):
        name = "#" + (self.room or "lobby")
        if name not in self.tabs:
            self.tabs.append(name)
        if name not in self.buffers:
            self.buffers[name] = []
        self.tab = self.tabs.index(name)
        self.unread.pop(name, None)
        self.room_id = self.room_ids.get(name, self.room_id)

    def room_label(self):
        """#name (id) — the id is what you share; the name is just a label."""
        name = self.room or "lobby"
        rid = self.room_ids.get("#" + name)
        return "#%s (%s)" % (name, rid) if rid else "#%s" % name

    def current_tab(self):
        return self.tabs[self.tab] if self.tabs else "#lobby"

    def buffer(self):
        return self.buffers.setdefault(self.current_tab(), [])

    def push(self, kind, text):
        self.buffer().append({"kind": kind, "text": text, "time": clock()})
        if kind == "msg":
            self.transcript.append((self.current_tab(), text))

    def add_message(self, nick, text, ts=None):
        tab = self.current_tab()
        mine = nick == self.handle
        self.buffers.setdefault(tab, []).append({
            "kind": "msg", "nick": nick, "text": text,
            "time": clock(ts), "mine": mine,
        })
        self.transcript.append((tab, "<%s> %s" % (nick, text)))
        self.scroll_reset_if_bottom()
        if not mine and self.mention_of_me(text):
            self.buffers[tab][-1]["mention"] = True
            self.alert_mention(nick, text)
        if tab != self.current_tab():
            self.unread[tab] = self.unread.get(tab, 0) + 1

    def mention_of_me(self, text):
        h = self.handle.lower()
        low = text.lower()
        if h in low:
            return True
        base = h.split("-")[0]
        return len(base) > 3 and ("@" + base) in low

    def alert_mention(self, nick, text):
        now = time.time()
        if now - self.last_mention_notify < 8:
            return
        self.last_mention_notify = now
        if self.mention_sound:
            self.bell()
        if self.notify_enabled:
            self.desktop_notify("%s mentioned you" % nick, text[:120])

    def bell(self):
        try:
            self.ui.out.write("\a")
            self.ui.out.flush()
        except Exception:
            pass

    def desktop_notify(self, title, body):
        if not shutil.which("notify-send"):
            return
        try:
            subprocess.Popen(["notify-send", "-a", "nullroom", "-u", "normal",
                              title, body],
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        except OSError:
            pass

    def track_membership(self, text):
        m = re.match(r"^(\S+) (joined|left)$", text)
        if m and m.group(1) != self.handle:
            delta = 1 if m.group(2) == "joined" else -1
            self.room_users = max(0, self.room_users + delta)

    def scroll_reset_if_bottom(self):
        if self.ui.scroll <= 1:
            self.ui.scroll = 0

    # ── rendering ───────────────────────────────────────────────────────
    def tick(self):
        self.ui.refresh_size()
        self.ui.messages = self.buffer()
        self.ui.scroll = self.ui.scroll
        now = time.time()

        if not self.connected and now >= self.next_reconnect and self.next_reconnect:
            self.next_reconnect = 0.0
            self.connect()
        if self.connected and now - self.last_ping > 10:
            self.last_ping = now
            self.ws.ping()

        self.draw()
        key = self.ui.read_key(timeout=0.05)
        if key != "NONE":
            self.handle_key(key)

    def draw(self):
        ui = self.ui
        ui.begin_frame()
        w, h = ui.width, ui.height

        badges = []
        if self.connected:
            lat = self.ws.latency if self.ws else None
            badges.append(("● live" + (" %dms" % lat if lat is not None else ""),
                           C_ACCENT))
        else:
            badges.append(("● offline", C_ERR))
        badges.append(("%d here" % self.room_users, C_DIM))

        title = self.room_label()
        subtitle = self.room_topic or self.handle
        ui.draw_header(title, " " + subtitle, badges)

        top = 2
        footer_row = h - 1
        input_row = h - 2
        status_row = h - 3
        help_row = h

        if self.view == "rooms":
            body_h = status_row - top
            ui.draw_room_list(top, 1, body_h, w, self.rooms,
                              selected=self.rooms_selected,
                              title="Public rooms — Enter to join, n for new, Esc to go back")
            ui.draw_input(input_row, prompt="join room: ",
                          placeholder="room name, then Enter")
        elif self.view == "help":
            body_h = status_row - top
            ui.draw_help_panel(top, 1, body_h, w, self.full_help())
            ui.draw_input(input_row, prompt="> ", placeholder="Esc to close")
        elif self.view == "invite":
            body_h = status_row - top
            self.draw_invite(top, 1, body_h, w)
            ui.draw_input(input_row, prompt="> ", placeholder="Esc to close")
        else:
            body_h = status_row - top
            ui.draw_messages(top, 1, body_h, w,
                             empty_hint="No messages yet. Say something — "
                                        "nothing here is stored.")
            ui.draw_input(input_row, placeholder="message #%s…" % (self.room or ""))

        # status line: tabs, typing, latency
        tabs = "  ".join(
            ("*%s%s" % (t, "" if not self.unread.get(t) else " (%d)" % self.unread[t]))
            for t in self.tabs
        ) or "(no tabs)"
        typing = self.typing_now()
        left = "%s   %s" % (tabs, typing) if typing else tabs
        right = "ping %sms" % (self.ws.latency if self.ws and self.ws.latency else "—")
        ui.draw_status(status_row, " " + left, right, self.status_colour)

        ui.draw_footer("  ".join("%s %s" % (k, d) for k, d in HELP_KEYS[:6]) +
                       "   ·  /help for all commands")
        ui.end_frame()

    def draw_invite(self, top, left, height, width):
        ui = self.ui
        ui._box(top, left, height, width, "Invite")
        lines = self.invite_text or self.build_invite()
        for i, line in enumerate(lines):
            if i >= height - 2:
                break
            style = fg(C_TEXT)
            if line.startswith("  Room ID"):
                style = BOLD + fg(C_ACCENT)
            elif line.startswith("  nullroom"):
                style = BOLD + fg(C_WARN)
            elif line.startswith("Keys:"):
                style = DIM + fg(C_ACCENT2)
            elif line and not line.startswith(" "):
                style = BOLD + fg(C_TEXT)
            ui._text_in(top, left, height, width, i, line, style)

    def full_help(self):
        lines = list(HELP_KEYS)
        lines += [("", "")]
        lines += [("/join NAME|ID", "join a room by name, id or invite"),
                  ("/create NAME TOPIC", "create a room and get its id"),
                  ("/invite", "show the invite, copy or save it"),
                  ("/lock [KEY]", "require a key to enter this room"),
                  ("/key", "lock with a fresh random key"),
                  ("/rotate", "new id; the old one stops working"),
                  ("/id", "show this room's id"),
                  ("/myrooms", "rooms you created this session"),
                  ("/topic TEXT", "set the room topic"),
                  ("/dm HANDLE", "explains why there are no DMs"),
                  ("/rooms", "refresh the room browser"),
                  ("/nick", "regenerate your handle"),
                  ("/me TEXT", "emote"),
                  ("/clear", "clear this tab"),
                  ("/search TEXT", "search scrollback"),
                  ("/next", "jump to next search hit"),
                  ("/save FILE", "export this tab's transcript"),
                  ("/theme NAME", "dark | light | contrast"),
                  ("/notify on|off", "desktop notifications"),
                  ("/sound on|off", "beep on mention"),
                  ("/server URL", "switch server"),
                  ("/rooms-json", "dump the room list as JSON"),
                  ("/who", "who is in this room"),
                  ("/limits", "server limits and version"),
                  ("/quit", "leave")]
        return lines

    def typing_now(self):
        cutoff = time.time() - 4
        names = [n for n, t in self.typing.items() if t > cutoff]
        if not names:
            return ""
        if len(names) == 1:
            return "%s is typing…" % names[0]
        return "%d people typing…" % len(names)

    # ── key handling ────────────────────────────────────────────────────
    def handle_key(self, key):
        ui = self.ui

        if key == "RESIZE":
            return
        if key == "CTRL-C":
            return
        if key == "CTRL-D":
            self.running = False
            return
        if key == "CTRL-L":
            ui._write("\x1b[2J")
            return
        if key == "CTRL-T":
            self.cycle_theme()
            return
        if key == "CTRL-R":
            self.view = "rooms" if self.view != "rooms" else "chat"
            self.refresh_rooms()
            return
        if key == "CTRL-N":
            self.prompt("new room name: ", self.create_room_named)
            return
        if key == "CTRL-J":
            self.prompt("room id or name: ", self.join_anything)
            return
        if key == "CTRL-I":
            self.show_invite()
            return
        if key == "CTRL-X":
            self.command("/close")
            return
        if key == "CTRL-F":
            self.prompt("search: ", self.do_search)
            return
        if key == "CTRL-S":
            self.save_transcript()
            return
        if key == "CTRL-O":
            self.open_last_url()
            return
        if key == "CTRL-P":
            self.prev_tab()
            return
        if key == "TAB":
            self.next_tab()
            return
        if key == "PGUP":
            ui.scroll += max(1, ui.height // 3)
            return
        if key == "PGDN":
            ui.scroll = max(0, ui.scroll - max(1, ui.height // 3))
            return
        if key == "ESC":
            if self.overlay:
                self.overlay = None
                return
            if self.view != "chat":
                self.view = "chat"
            return

        if self.overlay:
            self.overlay_key(key)
            return

        if self.view == "rooms":
            self.rooms_key(key)
            return
        if self.view == "invite":
            self.invite_key(key)
            return

        # chat input
        if key == "ENTER":
            text = ui.take_input()
            if text:
                self.submit(text)
            return
        if key == "BACKSPACE":
            ui.backspace()
            return
        if key == "DELETE":
            ui.delete_forward()
            return
        if key == "LEFT":
            ui.input_cursor = max(0, ui.input_cursor - 1)
            return
        if key == "RIGHT":
            ui.input_cursor = min(len(ui.input_buf), ui.input_cursor + 1)
            return
        if key == "HOME" or key == "CTRL-A":
            ui.input_cursor = 0
            return
        if key == "END" or key == "CTRL-E":
            ui.input_cursor = len(ui.input_buf)
            return
        if key in ("UP", "CTRL-P") and not self.overlay:
            ui.history_prev()
            return
        if key in ("DOWN", "CTRL-N") and not self.overlay:
            ui.history_next()
            return
        if key == "CTRL-U":
            ui.clear_input()
            return
        if key == "CTRL-W":
            self.delete_word()
            return
        if isinstance(key, tuple) and key and key[0] == "MOUSE":
            _, x, y, btn = key
            if btn == 64:
                ui.scroll += 3
            elif btn == 65:
                ui.scroll = max(0, ui.scroll - 3)
            return
        if len(key) == 1 and key.isprintable():
            ui.insert_text(key)
            if self.connected and self.current_tab().startswith("#"):
                self.ws.send({"t": "typing"})

    def delete_word(self):
        buf = self.ui.input_buf
        i = self.ui.input_cursor
        while i > 0 and buf[i - 1] == " ":
            i -= 1
        while i > 0 and buf[i - 1] != " ":
            i -= 1
        del buf[i:self.ui.input_cursor]
        self.ui.input_cursor = i

    def rooms_key(self, key):
        if key in ("UP", "CTRL-P"):
            self.rooms_selected = max(0, self.rooms_selected - 1)
        elif key in ("DOWN", "CTRL-N"):
            self.rooms_selected = min(max(0, len(self.rooms) - 1),
                                      self.rooms_selected + 1)
        elif key == "ENTER":
            text = self.ui.take_input()
            if text:
                self.join_anything(text)
            elif self.rooms:
                self.join_room(self.rooms[self.rooms_selected]["name"])
        elif key == "n":
            self.prompt("new room name: ", self.create_room_named)
        elif key == "i":
            self.show_invite()
        elif len(key) == 1 and key.isprintable():
            self.ui.insert_text(key)
        elif key == "BACKSPACE":
            self.ui.backspace()

    def invite_key(self, key):
        if key == "CTRL-Y" or key == "y":
            self.copy_invite()
        elif key == "CTRL-S" or key == "s":
            self.save_invite()
        elif key == "r":
            self.rotate_invite()
        elif key == "l":
            self.prompt("lock key (empty to unlock): ", self.lock_room)
        elif key == "g":
            self.new_invite_key()
        elif key == "ESC":
            self.view = "chat"

    # ── overlay prompt ──────────────────────────────────────────────────
    def prompt(self, label, callback):
        self.overlay = ("input", label, callback)
        self.ui.input_prompt = label
        self.ui.clear_input()

    def overlay_key(self, key):
        ui = self.ui
        if key == "ENTER":
            text = ui.take_input()
            _, _, callback = self.overlay
            self.overlay = None
            ui.input_prompt = "> "
            callback(text)
            return
        if key == "BACKSPACE":
            ui.backspace()
        elif key == "CTRL-U":
            ui.clear_input()
        elif len(key) == 1 and key.isprintable():
            ui.insert_text(key)

    # ── commands ────────────────────────────────────────────────────────
    def submit(self, text):
        if text.startswith("/"):
            self.command(text)
            return
        if not self.connected:
            self.push("err", "not connected — message not sent")
            return
        limit = self.limits.get("max_chars", 1000)
        if len(text) > limit:
            text = text[:limit]
        self.ws.send({"t": "msg", "text": text, "nick": self.handle})

    def command(self, line):
        parts = line.strip().split(" ", 1)
        cmd = parts[0].lower()
        arg = parts[1].strip() if len(parts) > 1 else ""

        if cmd in ("/quit", "/exit"):
            self.running = False
        elif cmd == "/help":
            self.view = "help"
        elif cmd == "/join" and arg:
            self.join_anything(arg)
        elif cmd == "/create":
            bits = arg.split(" ", 1) if arg else ["", ""]
            topic = bits[1] if len(bits) > 1 else None
            self.create_room(bits[0] or None, topic)
        elif cmd == "/invite":
            self.show_invite()
        elif cmd == "/lock":
            self.prompt("lock key (empty to unlock): ", self.lock_room)
        elif cmd == "/key":
            self.new_invite_key()
        elif cmd == "/rotate":
            self.rotate_invite()
        elif cmd == "/close":
            if not self.connected or not self.ws:
                self.push("err", "not connected")
            elif not self.owns_current_room():
                self.push("err", "only the room's creator can close it")
            else:
                self.ws.send({"t": "close-room"})
                self.push("sys", "closing #%s…" % (self.room or "?"))
        elif cmd == "/id":
            if self.room_id:
                self.push("sys", "room %s — id %s" % (self.room_label(), self.room_id))
            else:
                self.push("err", "this room has no id")
        elif cmd == "/myrooms":
            if not self.owned_rooms:
                self.push("sys", "you have not created a room this session")
            for name, info in self.owned_rooms.items():
                self.push("sys", "%s  id %s  topic %r" %
                          (name, info["id"], info.get("topic", "")))
        elif cmd == "/topic" and arg:
            if self.connected and self.ws and self.owns_current_room():
                self.ws.send({"t": "set-topic", "topic": arg})
            else:
                self.room_topic = arg
                self.push("sys", "topic set locally: %s" % arg)
                self.push("sep", "only the room's creator can change it for everyone")
        elif cmd == "/rooms":
            self.view = "rooms"
            self.refresh_rooms()
        elif cmd == "/nick":
            self.handle = random_handle()
            if self.connected:
                self.ws.send({"t": "hello", "nick": self.handle})
            self.push("sys", "you are now %s" % self.handle)
        elif cmd == "/me" and arg:
            if self.connected:
                self.ws.send({"t": "msg", "text": "* %s %s" % (self.handle, arg),
                              "nick": self.handle})
        elif cmd == "/clear":
            self.buffers[self.current_tab()] = []
        elif cmd == "/search" and arg:
            self.do_search(arg)
        elif cmd == "/next":
            self.next_hit()
        elif cmd == "/save":
            self.save_transcript(arg or None)
        elif cmd == "/invite":
            self.show_invite()
        elif cmd == "/theme" and arg:
            if arg in THEMES:
                self.theme_name = arg
                self.theme = THEMES[arg]
                self.push("sys", "theme: %s" % arg)
        elif cmd == "/notify" and arg:
            self.notify_enabled = arg.lower() == "on"
            self.push("sys", "notifications %s" % ("on" if self.notify_enabled else "off"))
        elif cmd == "/sound" and arg:
            self.mention_sound = arg.lower() == "on"
            self.push("sys", "mention sound %s" % ("on" if self.mention_sound else "off"))
        elif cmd == "/server" and arg:
            self.server = arg
            self.push("sys", "switching to %s" % arg)
            if self.ws:
                self.ws.close()
        elif cmd == "/dm" and arg:
            self.open_dm(arg)
        elif cmd == "/who":
            self.push("sys", "%d people in #%s" % (self.room_users, self.room))
        elif cmd == "/limits":
            self.push("sys", "server limits: %s" % json.dumps(self.limits))
        elif cmd == "/rooms-json":
            self.push("sys", json.dumps(self.rooms)[:2000])
        elif cmd == "/urls":
            urls = URL_RE.findall(" ".join(m.get("text", "") for m in self.buffer()))
            self.push("sys", "urls in this tab: %s" % (", ".join(urls[:10]) or "none"))
        else:
            self.push("err", "unknown command: %s  (try /help)" % cmd)

    def join_room(self, name, topic=None, room_id=None, key=None):
        name = (name or "lobby").strip().lower().lstrip("#")
        if not ROOM_ID_RE.match(name) and not re.match(
                r"^[a-z0-9][a-z0-9-]{1,31}$", name):
            self.push("err", "invalid room name (a-z, 0-9, hyphen; 2-32 chars)")
            return False
        if ROOM_ID_RE.match(name) and not room_id:
            # The whole token was an id: join by id, name arrives from the server.
            room_id, name = name, "lobby"
        self.room = name
        self.room_id = room_id or self.room_ids.get("#" + name)
        self.room_topic = topic if topic is not None else ""
        self.view = "chat"
        self.ui.clear_input()
        # Rooms are separate connections, so joining is a clean reconnect
        # with the id/key in the URL — never a message on the old socket.
        if self.ws:
            try:
                self.ws.close()
            except Exception:
                pass
        self.connect(room_override=name, room_id=room_id, key=key)
        self.ensure_tab()
        return True

    def join_anything(self, token):
        """Accept a room name or a room id or a full invite URL."""
        token = token.strip()
        # An invite link: ws://host:port/room?id=xxxxxx[&key=...]
        if "://" in token or "/" in token and "?" in token:
            self.join_invite(token)
            return
        token = token.lstrip("#")
        if ROOM_ID_RE.match(token.lower()):
            self.join_room(token, room_id=token.lower())
        else:
            self.join_room(token)

    def join_invite(self, url):
        """Join from an invite string a friend sent: either the full ws URL
        or just \"host:port/room?id=xxxxxx\"."""
        body = url.split("://", 1)[-1]
        frag = ""
        if "?" in body:
            body, frag = body.split("?", 1)
        params = {}
        for pair in frag.split("&"):
            if "=" in pair:
                k, v = pair.split("=", 1)
                params[k] = v
        if "/" in body:
            hostport, room = body.split("/", 1)
        else:
            hostport, room = body, "lobby"
        self.server = hostport
        room_id = params.get("id") or (room if ROOM_ID_RE.match(room.lower()) else None)
        key = params.get("key") or params.get("k")
        if self.ws:
            self.ws.close()
        self.join_room(room if not ROOM_ID_RE.match(room.lower()) else "lobby",
                       room_id=room_id, key=key)

    def resolve_and_join(self, room_id):
        self.join_room(room_id, room_id=room_id)

    def create_room(self, name=None, topic=None):
        """Create a room we own, then offer the invite.

        This is an explicit create message, not a join: the server records
        us as owner, which is what makes /lock and /rotate ours to use.
        """
        name = (name or ("room-" + make_room_id())).strip().lower().lstrip("#")
        if not re.match(r"^[a-z0-9][a-z0-9-]{1,31}$", name):
            self.push("err", "invalid room name (a-z, 0-9, hyphen; 2-32 chars)")
            return
        topic = topic if topic is not None else (self.room_topic or "")
        if not self.connected or not self.ws:
            self.push("err", "not connected — cannot create a room yet")
            return
        self.pending_room_creation = True
        self.pending_room_name = name
        # The server moves this connection into the new room on success,
        # so we set local state from the server's joined/room-id replies
        # (absorb_room + ensure_tab do that), not here.
        self.view = "chat"
        self.ui.clear_input()
        self.ws.send({"t": "create", "room": name, "topic": topic,
                      "nick": self.handle})
        self.push("sys", "creating #%s…" % name)

    def create_room_named(self, name):
        self.create_room(name)

    def show_invite(self):
        self.view = "invite"
        self.invite_text = self.build_invite()
        if self.room_id:
            self.copy_invite(silent=True)
            try:
                clip = self.invite_blob()
                self.push("sys", clip.rstrip())
            except Exception:
                pass
        if self.connected and self.ws:
            # Ask the server to confirm the id so it can never be stale.
            self.ws.send({"t": "id"})

    def build_invite(self):
        rid = self.room_id or "(pending)"
        lines = [
            "Invite someone to %s" % self.room_label(),
            "",
            "  Room name : %s" % (self.room or "?"),
            "  Room ID   : %s" % rid,
            "  Server    : %s" % self.server,
        ]
        if self.room_lock_key:
            lines.append("  Lock key  : %s" % self.room_lock_key)
        lines += [
            "",
            "Send them this one line:",
            "",
            "  %s" % self.invite_command(),
            "",
            "Keys:  y copy   s save   r rotate id   l lock   g new key   Esc back",
            "",
            "Anyone with the id can walk in unless you lock the room.",
            "Send the key separately from the id if it matters.",
            "",
            "Rooms are temporary: when the last person leaves, the room and",
            "its history are gone.",
        ]
        return lines

    def invite_target(self):
        """The canonical join target: server + path with id and key."""
        scheme, host, port, _ = parse_ws_url(self.server)
        base = "%s://%s" % (scheme, host)
        if not (scheme == "ws" and port == 80) and not (scheme == "wss" and port == 443):
            base += ":%d" % port
        path = "/" + (self.room or "lobby")
        query = []
        if self.room_id:
            query.append("id=" + self.room_id)
        if self.room_lock_key:
            query.append("key=" + self.room_lock_key)
        if query:
            path += "?" + "&".join(query)
        return base + path

    def invite_command(self):
        return "nullroom --invite %s" % self.invite_target()

    def invite_blob(self):
        bits = ["Join me in #%s on nullroom" % (self.room or "?"),
                "room id: %s" % (self.room_id or "?")]
        if self.room_lock_key:
            bits.append("key: %s" % self.room_lock_key)
        bits.append(self.invite_command())
        return "\n".join(bits) + "\n"

    def copy_invite(self, silent=False):
        blob = self.invite_blob()
        copied = False
        for tool, args in (("wl-copy", []), ("xclip", ["-selection", "clipboard"]),
                           ("xsel", ["--clipboard", "--input"]),
                           ("pbcopy", []), ("clip.exe", [])):
            if shutil.which(tool):
                try:
                    p = subprocess.Popen([tool] + args, stdin=subprocess.PIPE,
                                         stdout=subprocess.DEVNULL,
                                         stderr=subprocess.DEVNULL)
                    p.communicate(blob.encode("utf-8"))
                    copied = True
                    break
                except OSError:
                    continue
        if copied:
            self.push("sys", "invite copied to the clipboard")
        elif not silent:
            self.push("sys", "no clipboard tool found — press s to save it instead")

    def save_invite(self):
        path = os.path.join(os.getcwd(), "nullroom-invite-%s.txt"
                            % (self.room or "room"))
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write(self.invite_blob())
            self.push("sys", "invite written to %s" % path)
        except OSError as exc:
            self.push("err", "could not write invite: %s" % exc)

    def rotate_invite(self):
        """Ask the server for a fresh id. The old id stops working at once."""
        if not self.connected or not self.ws:
            self.push("err", "not connected")
            return
        if not self.owns_current_room():
            self.push("err", "only the room's creator can rotate its id")
            return
        self.ws.send({"t": "rotate-id"})
        self.push("sys", "asked the server to rotate this room's id…")

    def owns_current_room(self):
        return self.owned_rooms.get("#" + (self.room or "")) is not None

    def lock_room(self, key):
        if not self.connected or not self.ws:
            self.push("err", "not connected")
            return
        if not self.owns_current_room():
            self.push("err", "only the room's creator can lock it")
            return
        key = (key or "").strip()
        self.room_lock_key = key or None
        self.ws.send({"t": "lock", "key": key})
        if key:
            self.push("sys", "room locked — the invite now carries the key")
            self.copy_invite(silent=True)
        else:
            self.push("sys", "room unlocked — anyone with the id can enter")

    def new_invite_key(self):
        self.lock_room(make_room_id() + make_room_id())

    def fetch_rooms(self):
        """Blocking room-list fetch. Returns the list or None."""
        try:
            import urllib.request
            base = self.server.replace("wss://", "https://").replace("ws://", "http://")
            base = base.rstrip("/")
            with urllib.request.urlopen(base + "/api/rooms", timeout=6) as r:
                data = json.loads(r.read().decode("utf-8"))
            return data.get("rooms", [])
        except Exception:
            return None

    def refresh_rooms(self):
        def work():
            rooms = self.fetch_rooms()
            if rooms is None:
                self.push("err", "could not fetch the room list")
                return
            self.rooms = rooms
            self.rooms_selected = min(self.rooms_selected,
                                      max(0, len(self.rooms) - 1))
            for r in rooms:
                if r.get("id"):
                    self.room_ids["#" + r["name"]] = r["id"]
        threading.Thread(target=work, daemon=True).start()

    def open_dm(self, handle):
        self.push("sep", "direct messages are not part of this server. Every")
        self.push("sep", "room is readable by anyone who has its name or id —")
        self.push("sep", "do not use rooms for anything private.")

    def next_tab(self):
        if not self.tabs:
            return
        self.tab = (self.tab + 1) % len(self.tabs)
        self.unread.pop(self.current_tab(), None)
        self.ui.scroll = 0

    def prev_tab(self):
        if not self.tabs:
            return
        self.tab = (self.tab - 1) % len(self.tabs)
        self.unread.pop(self.current_tab(), None)
        self.ui.scroll = 0

    def cycle_theme(self):
        names = list(THEMES)
        self.theme_name = names[(names.index(self.theme_name) + 1) % len(names)]
        self.theme = THEMES[self.theme_name]
        self.push("sys", "theme: %s" % self.theme_name)

    def do_search(self, query):
        self.filter_query = query
        hits = []
        for i, m in enumerate(self.buffer()):
            if query.lower() in json.dumps(m).lower():
                hits.append(i)
        self.search_hits = hits
        self.search_index = 0
        if hits:
            self.ui.scroll = max(0, len(self.buffer()) - hits[0] - 1)
            self.push("sys", "%d hits for '%s' — /next to step" % (len(hits), query))
        else:
            self.push("err", "no hits for '%s'" % query)

    def next_hit(self):
        if not self.search_hits:
            self.push("err", "no active search")
            return
        self.search_index = (self.search_index + 1) % len(self.search_hits)
        idx = self.search_hits[self.search_index]
        self.ui.scroll = max(0, len(self.buffer()) - idx - 1)

    def save_transcript(self, path=None):
        path = path or os.path.join(
            os.getcwd(), "nullroom-%s-%s.txt" % (
                (self.room or "session"), time.strftime("%Y%m%d-%H%M%S")))
        try:
            with open(path, "w", encoding="utf-8") as fh:
                fh.write("# nullroom transcript — %s\n" % time.strftime("%c"))
                fh.write("# server %s · room #%s · handle %s\n" % (
                    self.server, self.room, self.handle))
                fh.write("# NOTE: saved by you, on your machine. The server "
                         "stores nothing.\n\n")
                for tab, line in self.transcript:
                    fh.write("%s %s\n" % (tab, line))
            self.push("sys", "saved transcript: %s" % path)
        except OSError as exc:
            self.push("err", "could not save: %s" % exc)

    def open_last_url(self):
        text = " ".join(m.get("text", "") for m in self.buffer())
        urls = URL_RE.findall(text)
        if not urls:
            self.push("err", "no url in this tab")
            return
        url = urls[-1]
        self.last_url = url
        opener = shutil.which("xdg-open") or shutil.which("open")
        if not opener:
            self.push("sys", "url: %s" % url)
            return
        try:
            subprocess.Popen([opener, url], stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
            self.push("sys", "opened %s" % url)
        except OSError:
            self.push("sys", "url: %s" % url)


def clock(ts_ms=None):
    if ts_ms:
        t = time.localtime(ts_ms / 1000.0)
    else:
        t = time.localtime()
    return time.strftime("%H:%M", t)


# ── entry point ─────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        prog="nullroom", description="Anonymous chat, from your terminal.")
    ap.add_argument("--server", "-s", default=None,
                    help="server address, e.g. chat.example.com or wss://host")
    ap.add_argument("--room", "-r", default=None, help="join this room at startup")
    ap.add_argument("--nick", "-n", default=None, help="use this handle")
    ap.add_argument("--invite", "-i", default=None,
                    help="join from an invite string, e.g. "
                         "chat.example.com/kali?id=k6bb4h")
    ap.add_argument("--theme", "-t", default=None, choices=list(THEMES))
    ap.add_argument("--no-notify", action="store_true",
                    help="do not use desktop notifications")
    ap.add_argument("--version", action="version", version="nullroom " + VERSION)
    args = ap.parse_args()

    cfg = load_config()
    server = args.server or cfg.get("server") or DEFAULT_SERVER
    theme = args.theme or cfg.get("theme") or "dark"
    room = args.room or cfg.get("room")

    if args.invite:
        # An invite carries its own server, room and id.
        invite_server, invite_room, invite_id, invite_key = parse_invite(args.invite)
        server = invite_server or server
        room = invite_room or room
    else:
        invite_id = invite_key = None

    if not sys.stdin.isatty() or not sys.stdout.isatty():
        print("nullroom needs an interactive terminal.", file=sys.stderr)
        print("Try: python3 client.py --server %s" % server, file=sys.stderr)
        return 2

    cfg.update({"server": server, "theme": theme})
    if room:
        cfg["room"] = room
    save_config(cfg)

    app = App(server=server, room=room, handle=args.nick, theme=theme,
              notify=not args.no_notify)
    if args.invite:
        app.room_id = invite_id
        app.room_lock_key = invite_key
    try:
        return app.run()
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main())
