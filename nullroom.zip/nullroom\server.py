"""
server.py — the whole application.

Anonymous, login-free, in-memory-only chat. Standard library only.

Privacy architecture (not a promise, a property of the code):
  * Rooms and messages live in dicts in RAM. Nothing is written to disk.
    Restarting the process destroys every message, unrecoverably, for
    everyone including the operator.
  * Client IP addresses are never stored, never written to a log file,
    and never included in a broadcast. They exist only as the socket's
    own peer address for the lifetime of the connection.
  * Access logging is off by default. Set ACCESS_LOG=1 to turn it on
    (it prints method+path+status only — never an IP, never a body).
  * No cookies, no localStorage identifiers, no analytics, no third-party
    requests from the frontend.
  * Display names are chosen by the client, per room, and are not tied to
    any identity across rooms or sessions.

Production features:
  * Threaded TCP server with keep-alive, timeouts, and graceful shutdown.
  * Per-connection rate limiting (token bucket) and message size caps.
  * Slow-client protection: bounded per-client send queue, dropped on flood.
  * Room capacity limits and idle-room reaping so RAM cannot grow forever.
  * /healthz for load balancers, /api/rooms for the room list.
  * Optional reverse-proxy awareness (X-Forwarded-For is used ONLY to
    decide rate-limit buckets when TRUST_PROXY=1; it is never stored).
  * Static files served with correct MIME types and cache headers.
"""

import hashlib
import hmac
import json
import os
import re
import secrets
import signal
import socket
import socketserver
import sys
import threading
import time
from http import HTTPStatus
from urllib.parse import urlparse, unquote

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from ws import WebSocket, WSError, WSClosed

VERSION = "1.2.0"

# --------------------------------------------------------------------------
# Configuration (all overridable by environment variable)
# --------------------------------------------------------------------------

HOST = os.environ.get("HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", "8080"))

MAX_ROOMS = int(os.environ.get("MAX_ROOMS", "200"))
MAX_USERS_PER_ROOM = int(os.environ.get("MAX_USERS_PER_ROOM", "80"))
MAX_MESSAGE_CHARS = int(os.environ.get("MAX_MESSAGE_CHARS", "1000"))
MAX_MESSAGES_PER_MIN = int(os.environ.get("MAX_MESSAGES_PER_MIN", "30"))
MAX_ROOMS_PER_USER = int(os.environ.get("MAX_ROOMS_PER_USER", "10"))
BACKLOG_PER_ROOM = int(os.environ.get("BACKLOG_PER_ROOM", "50"))
ROOM_IDLE_SECONDS = int(os.environ.get("ROOM_IDLE_SECONDS", "1800"))  # 30 min
ROOM_TTL_SECONDS = int(os.environ.get("ROOM_TTL_SECONDS", "21600"))  # 6 h hard cap
MAX_ROOM_NAME = 32
ROOM_TOPIC_MAX = 80
SEND_QUEUE_LIMIT = int(os.environ.get("SEND_QUEUE_LIMIT", "200"))
ACCESS_LOG = os.environ.get("ACCESS_LOG", "0") == "1"
FILTER_PROFANITY = os.environ.get("FILTER_PROFANITY", "0") == "1"
FILTER_URLS = os.environ.get("FILTER_URLS", "0") == "1"
TRUST_PROXY = os.environ.get("TRUST_PROXY", "0") == "1"
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")

ROOM_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{1,%d}$" % (MAX_ROOM_NAME - 1))
RESERVED = {
    "api", "static", "healthz", "favicon.ico", "robots.txt",
    "admin", "root", "system", "server", "null", "undefined",
}

# Room ids: a short, readable, unambiguous alphabet. Not a secret — see
# derive_room_id(). ID_SALT is per-deployment, so ids differ between servers.
ID_ALPHABET = "23456789abcdefghjkmnpqrstuvwxyz"
ID_LENGTH = 6
ID_SALT = os.environ.get("ID_SALT", "nullroom-v1")
ROOM_ID_RE = re.compile(r"^[%s]{%d}$" % (ID_ALPHABET, ID_LENGTH))

# Rooms whose id is required to enter. Owners can lock a room with /lock.
REQUIRE_INVITE_DEFAULT = os.environ.get("REQUIRE_INVITE", "0") == "1"

# Tiny profanity list for the optional filter (FILTER_PROFANITY=1).
# Deliberately small and bland: a word list is a blunt instrument, and
# over-blocking is worse than under-blocking in a room built for talking.
PROFANITY = {
    "fuck", "fucking", "shit", "bitch", "cunt", "asshole", "bastard",
    "dickhead", "wanker", "nigger", "faggot", "retard",
}
URL_RE = re.compile(r"\b(?:https?://|www\.)\S+", re.IGNORECASE)

MIME = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".ico": "image/x-icon",
    ".txt": "text/plain; charset=utf-8",
    ".webmanifest": "application/manifest+json",
    ".woff2": "font/woff2",
}

# --------------------------------------------------------------------------
# In-memory state. This is the entire database.
# --------------------------------------------------------------------------


def derive_room_id(name):
    """A room's shareable id, derived from its name.

    Deterministic on purpose: two people who are told the same room name
    compute the same id, so an id can be passed around without the server
    storing a mapping. It is an identifier, not a secret.
    """
    digest = hashlib.sha256((ID_SALT + name).encode("utf-8")).digest()
    return "".join(ID_ALPHABET[b % len(ID_ALPHABET)] for b in digest[:ID_LENGTH])


class Room:
    __slots__ = ("name", "topic", "clients", "backlog", "created",
                 "last_active", "owner", "locked", "roomsalt", "lock_hash")

    def __init__(self, name, topic="", owner=None, locked=False):
        self.name = name
        self.topic = topic
        self.clients = set()      # set of Client
        self.backlog = []         # list of dicts, capped at BACKLOG_PER_ROOM
        self.created = time.time()
        self.last_active = time.time()
        self.owner = owner
        self.locked = locked
        # A per-room salt folded into the id. The owner can rotate it to
        # invalidate an old id without renaming the room.
        self.roomsalt = ""
        self.lock_hash = ""

    def room_id(self):
        return derive_room_id(self.name + self.roomsalt)


class Client:
    __slots__ = (
        "ws", "room", "nick", "addr", "send_q", "alive", "named",
        "bucket", "bucket_ts", "connected_at", "warned",
    )

    def __init__(self, ws, addr):
        self.ws = ws
        self.room = None
        self.nick = "anon"
        self.addr = addr
        self.send_q = []
        self.alive = True
        self.named = False
        self.bucket = float(MAX_MESSAGES_PER_MIN)
        self.bucket_ts = time.time()
        self.connected_at = time.time()
        self.warned = 0


ROOMS = {}
ROOMS_LOCK = threading.RLock()
SERVER_START = time.time()
STATS = {
    "messages": 0,
    "connections": 0,
    "rejected": 0,
    "filtered": 0,
    "started": time.time(),
}


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------


def now_ms():
    return int(time.time() * 1000)


def sanitize_topic(raw):
    if not isinstance(raw, str):
        return None
    raw = "".join(c for c in raw.strip() if c.isprintable())
    raw = raw[:ROOM_TOPIC_MAX].strip()
    return raw or None


def sanitize_key(raw):
    if not isinstance(raw, str):
        return ""
    raw = "".join(c for c in raw if c.isprintable())
    return raw.strip()[:128]


def sanitize_nick(raw):
    if not isinstance(raw, str):
        return None
    raw = raw.strip()
    if not raw:
        return None
    # Keep it printable and short. Strip anything that could be used for
    # impersonation of the system (angle brackets) or control characters.
    raw = "".join(ch for ch in raw if ch.isprintable() and ch not in "<>")
    raw = raw[:24].strip()
    return raw or None


def sanitize_message(raw):
    if not isinstance(raw, str):
        return None
    # Collapse runaway whitespace, drop control characters other than \n.
    raw = raw.replace("\r\n", "\n").replace("\r", "\n")
    raw = "".join(ch for ch in raw if ch == "\n" or ch.isprintable())
    raw = raw.strip()
    if not raw:
        return None
    if FILTER_PROFANITY:
        raw = mask_profanity(raw)
    if FILTER_URLS:
        raw = URL_RE.sub("[link removed]", raw)
    if len(raw) > MAX_MESSAGE_CHARS:
        raw = raw[:MAX_MESSAGE_CHARS]
    return raw


def mask_profanity(text):
    """Replace the middle of each flagged word with asterisks, keeping the
    first and last letter so the sentence still reads."""
    def repl(match):
        word = match.group(0)
        if len(word) <= 3:
            return word[0] + "*" * (len(word) - 1)
        return word[0] + "*" * (len(word) - 2) + word[-1]

    return re.sub(
        r"\b(" + "|".join(re.escape(w) for w in PROFANITY) + r")\b",
        repl,
        text,
        flags=re.IGNORECASE,
    )


def room_public(room):
    return {
        "name": room.name,
        "topic": room.topic,
        "users": len(room.clients),
        "created": int(room.created * 1000),
        "ttl": max(0, int(room.created + ROOM_TTL_SECONDS - time.time())),
        "id": room.room_id(),
        "owner": room.owner or "",
        "locked": room.locked,
    }


def rooms_snapshot():
    with ROOMS_LOCK:
        items = [room_public(r) for r in ROOMS.values()]
    items.sort(key=lambda r: (-r["users"], r["name"]))
    return items


def reap_idle_rooms():
    """Empty rooms past ROOM_IDLE_SECONDS, and any room past its hard TTL,
    are deleted. Nothing persists."""
    cutoff = time.time() - ROOM_IDLE_SECONDS
    ttl_cutoff = time.time() - ROOM_TTL_SECONDS
    with ROOMS_LOCK:
        dead = [
            n for n, r in ROOMS.items()
            if (not r.clients and r.last_active < cutoff) or r.created < ttl_cutoff
        ]
        for n in dead:
            del ROOMS[n]
    return len(dead)


# --------------------------------------------------------------------------
# Broadcasting
# --------------------------------------------------------------------------


def enqueue(client, payload):
    """Non-blocking send. A client that cannot keep up is disconnected
    rather than allowed to consume unbounded server memory."""
    if not client.alive:
        return
    if len(client.send_q) >= SEND_QUEUE_LIMIT:
        client.alive = False
        return
    client.send_q.append(payload)


def broadcast(room, payload, exclude=None):
    for c in list(room.clients):
        if c is exclude:
            continue
        enqueue(c, payload)


def send_json(client, obj):
    enqueue(client, json.dumps(obj, separators=(",", ":")))


def system_message(room, text):
    broadcast(room, json.dumps(
        {"t": "sys", "text": text, "ts": now_ms()},
        separators=(",", ":"),
    ))


# --------------------------------------------------------------------------
# Protocol
# --------------------------------------------------------------------------


def handle_message(client, raw):
    try:
        msg = json.loads(raw)
    except (ValueError, TypeError):
        send_json(client, {"t": "err", "text": "Malformed message."})
        return
    if not isinstance(msg, dict):
        return

    kind = msg.get("t")

    if kind == "hello":
        # Nick handshake. The client names itself here; the room was already
        # decided by the URL. Naming is separate from creating: a room you
        # merely walk into has no owner, and never gets one.
        nick = sanitize_nick(msg.get("nick"))
        if nick:
            client.nick = nick
            client.named = True
        else:
            client.nick = "anon-" + secrets.token_hex(2)
        send_json(client, {
            "t": "welcome",
            "nick": client.nick,
            "room": room_public(client.room) if client.room else None,
            "limits": {
                "max_chars": MAX_MESSAGE_CHARS,
                "per_minute": MAX_MESSAGES_PER_MIN,
                "max_users": MAX_USERS_PER_ROOM,
            },
        })
        if client.room:
            backlog = list(client.room.backlog)
            send_json(client, {"t": "backlog", "items": backlog})
        return

    if kind == "create":
        # Create a room with a claimed name. This is the only way a room
        # gets an owner: the creator names themselves first, so ownership
        # is never decided by whichever connection happened to arrive
        # first (which was a race, and made "anon" the owner of everything).
        name = (msg.get("room") or "").strip().lower().lstrip("#")
        topic = sanitize_topic(msg.get("topic")) or ""
        nick = sanitize_nick(msg.get("nick")) or client.nick
        client.nick = nick
        client.named = True

        if not ROOM_NAME_RE.match(name) or name in RESERVED:
            send_json(client, {
                "t": "err",
                "text": "Invalid room name. Use 2-32 characters: a-z, 0-9, hyphen.",
            })
            return

        with ROOMS_LOCK:
            existing = ROOMS.get(name)
            if existing is not None:
                send_json(client, {
                    "t": "err",
                    "text": f"A room called '{name}' already exists. "
                            f"Pick another name, or join it with /join {name}.",
                    "exists": True,
                })
                return
            if len(ROOMS) >= MAX_ROOMS:
                send_json(client, {
                    "t": "err",
                    "text": "Server is at room capacity. Try again shortly.",
                })
                return
            room = Room(name, topic, owner=nick)
            ROOMS[name] = room
            # The creator moves into the new room. A connection is in exactly
            # one room, so leave the URL room first if it is different.
            old = client.room
            if old is not None and old is not room:
                old.clients.discard(client)
                old.last_active = time.time()
            room.clients.add(client)
            client.room = room
            room.last_active = time.time()

        send_json(client, {"t": "joined", "room": room_public(room),
                           "created": True, "you_own_it": True})
        system_message(room, f"{nick} created this room")
        return

    if kind == "msg":
        # Token bucket: MAX_MESSAGES_PER_MIN sustained, small burst allowed.
        t = time.time()
        elapsed = t - client.bucket_ts
        client.bucket = min(
            float(MAX_MESSAGES_PER_MIN),
            client.bucket + elapsed * (MAX_MESSAGES_PER_MIN / 60.0),
        )
        client.bucket_ts = t
        if client.bucket < 1.0:
            if client.warned < 3:
                client.warned += 1
                send_json(client, {
                    "t": "err",
                    "text": "Slow down — you're sending too fast.",
                })
            return
        client.bucket -= 1.0

        text = sanitize_message(msg.get("text"))
        if not text:
            return

        room = client.room
        if room is None:
            return

        nick = sanitize_nick(msg.get("nick")) or client.nick
        client.nick = nick

        entry = {
            "t": "msg",
            "id": secrets.token_hex(6),
            "nick": nick,
            "text": text,
            "ts": now_ms(),
        }
        room.last_active = time.time()
        room.backlog.append(entry)
        if len(room.backlog) > BACKLOG_PER_ROOM:
            del room.backlog[:-BACKLOG_PER_ROOM]
        STATS["messages"] += 1
        # A message that left sanitize_message different from what was sent
        # was changed by the profanity filter, the URL filter, or the cap.
        sent = (msg.get("text") or "")[:MAX_MESSAGE_CHARS].strip()
        if text != sent:
            STATS["filtered"] += 1
        broadcast(room, json.dumps(entry, separators=(",", ":")))
        return

    if kind == "typing":
        if client.room:
            broadcast(client.room, json.dumps({
                "t": "typing",
                "nick": client.nick,
            }, separators=(",", ":")), exclude=client)
        return

    if kind == "id":
        room = client.room
        if room is None:
            return
        send_json(client, {
            "t": "room-id",
            "id": room.room_id(),
            "name": room.name,
            "locked": room.locked,
            "owner": room.owner or "",
            "you_own_it": bool(room.owner) and room.owner == client.nick,
        })
        return

    if kind == "rotate-id":
        room = client.room
        if room is None:
            return
        if room.owner and room.owner != client.nick:
            send_json(client, {"t": "err",
                               "text": "Only the room's creator can change its id."})
            return
        with ROOMS_LOCK:
            room.roomsalt = secrets.token_hex(4)
            new_id = room.room_id()
        system_message(room, f"{client.nick} rotated the room id — "
                             f"the old one no longer opens this room")
        send_json(client, {"t": "room-id", "id": new_id, "name": room.name,
                           "locked": room.locked, "owner": room.owner or "",
                           "you_own_it": True, "rotated": True})
        return

    if kind == "set-topic":
        room = client.room
        text = sanitize_topic(msg.get("topic"))
        if room is None or text is None:
            return
        if room.owner and room.owner != client.nick:
            send_json(client, {"t": "err",
                               "text": "Only the room's creator can set its topic."})
            return
        with ROOMS_LOCK:
            room.topic = text
        broadcast(room, json.dumps({
            "t": "topic", "topic": text, "by": client.nick,
        }, separators=(",", ":")))
        system_message(room, f"topic: {text}")
        return

    if kind == "close-room":
        room = client.room
        if room is None:
            return
        if not room.owner or room.owner != client.nick:
            send_json(client, {"t": "err",
                               "text": "Only the room's creator can close it."})
            return
        # Handled on a thread: close_room waits 150ms so the notice flushes
        # before the sockets drop. Blocking the read loop would stall pings.
        threading.Thread(target=close_room, args=(room, client),
                         daemon=True).start()
        return

    if kind == "lock":
        room = client.room
        if room is None:
            return
        if room.owner and room.owner != client.nick:
            send_json(client, {"t": "err",
                               "text": "Only the room's creator can lock it."})
            return
        key = sanitize_key(msg.get("key"))
        with ROOMS_LOCK:
            room.locked = bool(key)
            room.lock_hash = (hashlib.sha256(key.encode("utf-8")).hexdigest()
                              if key else "")
        if key:
            system_message(room, "this room is now locked — new joiners need the key")
            send_json(client, {"t": "lock-state", "locked": True})
        else:
            system_message(room, "this room is now open to anyone with the id")
            send_json(client, {"t": "lock-state", "locked": False})
        return

    if kind == "ping":
        send_json(client, {"t": "pong"})
        return

    if kind == "leave":
        raise WSClosed()


def room_join(client, room_name, topic_hint="", room_id=None, key=None):
    with ROOMS_LOCK:
        room = ROOMS.get(room_name)

        # Joining by id: the id identifies the room without the joiner
        # needing its name. Ids are deterministic, so they resolve across
        # the live room set with no stored mapping.
        if room is None and room_id:
            target = room_id.strip().lower()
            if not ROOM_ID_RE.match(target):
                send_json(client, {"t": "err",
                                   "text": "That does not look like a room id."})
                return False
            for candidate in ROOMS.values():
                if hmac.compare_digest(candidate.room_id(), target):
                    room = candidate
                    break
            if room is None:
                send_json(client, {
                    "t": "err",
                    "text": "No live room with that id. It may have expired — "
                            "rooms here are temporary.",
                })
                return False
            room_name = room.name

        if room is None:
            if len(ROOMS) >= MAX_ROOMS:
                send_json(client, {
                    "t": "err",
                    "text": "Server is at room capacity. Try again shortly.",
                })
                return False
            # Walk-in creation has no owner. Ownership comes only from an
            # explicit 'create', so it is never assigned by arrival order.
            room = Room(room_name, topic_hint or "", owner=None)
            ROOMS[room_name] = room

        if room.locked:
            want = hashlib.sha256((key or "").encode("utf-8")).hexdigest()
            if not hmac.compare_digest(want, room.lock_hash):
                send_json(client, {
                    "t": "err",
                    "text": "This room is locked. You need its key to enter.",
                    "locked": True,
                })
                return False

        if len(room.clients) >= MAX_USERS_PER_ROOM:
            send_json(client, {
                "t": "err",
                "text": f"Room '{room_name}' is full ({MAX_USERS_PER_ROOM} max).",
            })
            return False
        room.clients.add(client)
        client.room = room
        room.last_active = time.time()

    send_json(client, {"t": "joined", "room": room_public(room)})
    system_message(room, f"{client.nick} joined")
    return True


def room_leave(client):
    room = client.room
    if room is None:
        return
    with ROOMS_LOCK:
        room.clients.discard(client)
        room.last_active = time.time()
    client.room = None
    if room.clients:
        system_message(room, f"{client.nick} left")
    else:
        room.backlog.clear()


def close_room(room, requester, reason=None):
    """Remove a room at once. Everyone inside is told, then disconnected:
    the notice goes out first so the client's read loop delivers it before
    the socket goes away. The backlog dies with the room."""
    reason = reason or f"closed by {requester.nick}"
    with ROOMS_LOCK:
        members = list(room.clients)
        room.clients.clear()
        room.backlog.clear()
        gone = ROOMS.pop(room.name, None) is not None
    if not gone:
        return False
    notice = json.dumps(
        {"t": "closed", "room": room.name, "reason": reason}, separators=(",", ":"))
    for c in members:
        c.room = None
        enqueue(c, notice)
    # Give the pump threads one tick to flush the notice, then drop every
    # socket. A connection that outlives its room makes no sense.
    time.sleep(0.15)
    for c in members:
        c.alive = False
        try:
            c.ws.close(1000, b"room closed")
        except Exception:
            pass
    return True


# --------------------------------------------------------------------------
# Connection worker
# --------------------------------------------------------------------------


def pump_sends(client):
    """Drain the client's send queue. One thread per connection writes here."""
    ws = client.ws
    last_ping = time.time()
    while client.alive:
        if client.send_q:
            payload = client.send_q.pop(0)
            try:
                ws.send(payload)
            except (WSClosed, WSError, OSError):
                client.alive = False
                break
            continue
        if time.time() - last_ping > 25:
            try:
                ws.ping()
            except Exception:
                client.alive = False
                break
            last_ping = time.time()
        time.sleep(0.02)


def serve_connection(sock, addr, headers=None, path="/", query=""):
    headers = headers or {}

    try:
        ws = WebSocket.accept(sock, headers)
    except Exception:
        try:
            sock.close()
        except Exception:
            pass
        return

    ws.max_message = MAX_MESSAGE_CHARS * 8

    client = Client(ws, addr)
    STATS["connections"] += 1

    # Path decides the room: /ws/<room>
    room_name = path[len("/ws/"):].strip("/").lower()
    topic_hint = ""
    room_id = None
    room_key = None
    if query:
        from urllib.parse import parse_qs
        qs = parse_qs(query)
        topic_hint = (qs.get("topic", [""])[0] or "")[:ROOM_TOPIC_MAX]
        topic_hint = "".join(c for c in topic_hint if c.isprintable())
        room_id = (qs.get("id", [""])[0] or "").strip().lower() or None
        room_key = (qs.get("key", [""])[0] or "")[:128]

    # Joining by id: the path segment is not a room name at all, so the
    # name check is skipped and room_join resolves the id instead.
    if not room_id and (not ROOM_NAME_RE.match(room_name)
                        or room_name in RESERVED):
        send_json(client, {
            "t": "err",
            "text": "Invalid room name. Use 2-32 characters: a-z, 0-9, hyphen.",
        })
        sender = threading.Thread(target=pump_sends, args=(client,), daemon=True)
        sender.start()
        time.sleep(0.2)
        client.alive = False
        ws.close(1008, b"bad room")
        return

    sender = threading.Thread(target=pump_sends, args=(client,), daemon=True)
    sender.start()

    if not room_join(client, room_name, topic_hint, room_id=room_id,
                     key=room_key):
        time.sleep(0.2)
        client.alive = False
        ws.close(1008, b"rejected")
        return

    try:
        while client.alive:
            try:
                raw = ws.recv()
            except WSClosed:
                break
            except WSError:
                break
            if len(raw) > MAX_MESSAGE_CHARS * 8:
                break
            handle_message(client, raw)
    except Exception:
        pass
    except BaseException:
        # A frame we cannot parse must never take the process down with it.
        pass
    finally:
        client.alive = False
        try:
            room_leave(client)
        except Exception:
            pass
        ws.close()
        try:
            sock.close()
        except Exception:
            pass


# --------------------------------------------------------------------------
# HTTP layer (static files + JSON API) and the upgrade switch
# --------------------------------------------------------------------------


class Handler(socketserver.BaseRequestHandler):
    def handle(self):
        sock = self.request
        sock.settimeout(30)
        try:
            data = self._read_request_head(sock)
        except (socket.timeout, OSError):
            self._safe_close()
            return
        if data is None:
            self._safe_close()
            return

        head, rest = data
        lines = head.split("\r\n")
        request_line = lines[0]
        parts = request_line.split(" ")
        if len(parts) < 3:
            self._safe_close()
            return
        method, target, _version = parts[0], parts[1], parts[2]

        headers = {}
        for line in lines[1:]:
            if ":" in line:
                k, v = line.split(":", 1)
                headers[k.strip().lower()] = v.strip()

        parsed = urlparse(target)
        path = unquote(parsed.path)
        query = parsed.query

        # --- WebSocket upgrade ---
        if headers.get("upgrade", "").lower() == "websocket":
            sock.settimeout(None)
            try:
                serve_connection(sock, self.client_address, headers, path, query)
            except Exception:
                # A broken client must never take the process down.
                try:
                    sock.close()
                except Exception:
                    pass
            return

        # --- Plain HTTP ---
        try:
            self._serve_http(sock, method, path, query, headers)
        except Exception:
            try:
                self._safe_close()
            except Exception:
                pass

    def _read_request_head(self, sock):
        buf = b""
        while b"\r\n\r\n" not in buf:
            try:
                chunk = sock.recv(8192)
            except (socket.timeout, OSError):
                return None
            if not chunk:
                return None
            buf += chunk
            if len(buf) > 64 * 1024:
                return None
        head, _, rest = buf.partition(b"\r\n\r\n")
        try:
            return head.decode("latin-1"), rest
        except Exception:
            return None

    def _serve_http(self, sock, method, path, query, headers):
        status = 200
        try:
            if method not in ("GET", "HEAD", "OPTIONS"):
                status = 405
                self._respond(sock, status, b"", "text/plain; charset=utf-8",
                              extra={"Allow": "GET, HEAD, OPTIONS"})
                return

            if method == "OPTIONS":
                self._respond(sock, 204, b"", "text/plain",
                              extra={"Allow": "GET, HEAD, OPTIONS"})
                return

            if path == "/healthz":
                body = json.dumps({
                    "ok": True,
                    "uptime_s": int(time.time() - SERVER_START),
                    "rooms": len(ROOMS),
                    "users": sum(len(r.clients) for r in ROOMS.values()),
                    "messages": STATS["messages"],
                    "filtered": STATS["filtered"],
                    "no_disk": True,
                    "no_ip_logging": True,
                }).encode()
                self._respond(sock, 200, body, MIME[".json"],
                              extra={"Cache-Control": "no-store"})
                return

            if path == "/api/rooms":
                body = json.dumps({
                    "rooms": rooms_snapshot(),
                    "server": {
                        "version": VERSION,
                        "protocol": 2,
                        "software": "nullroom",
                        "features": [
                            "room-ids", "room-lock", "rotate-id", "topic",
                            "filter-profanity", "filter-urls",
                        ],
                    },
                    "limits": {
                        "max_users_per_room": MAX_USERS_PER_ROOM,
                        "max_message_chars": MAX_MESSAGE_CHARS,
                        "messages_per_minute": MAX_MESSAGES_PER_MIN,
                        "room_idle_seconds": ROOM_IDLE_SECONDS,
                        "backlog_per_room": BACKLOG_PER_ROOM,
                    },
                }).encode()
                self._respond(sock, 200, body, MIME[".json"],
                              extra={"Cache-Control": "no-store"})
                return

            if path == "/api/config":
                body = json.dumps({
                    "max_message_chars": MAX_MESSAGE_CHARS,
                    "max_users_per_room": MAX_USERS_PER_ROOM,
                    "messages_per_minute": MAX_MESSAGES_PER_MIN,
                    "backlog_per_room": BACKLOG_PER_ROOM,
                    "room_idle_minutes": ROOM_IDLE_SECONDS // 60,
                    "room_ttl_minutes": ROOM_TTL_SECONDS // 60,
                    "max_rooms": MAX_ROOMS,
                    "filter_profanity": FILTER_PROFANITY,
                    "filter_urls": FILTER_URLS,
                    "protocol": 2,
                    "software": "nullroom",
                    "version": VERSION,
                    "room_id_length": ID_LENGTH,
                    "require_invite_default": REQUIRE_INVITE_DEFAULT,
                }).encode()
                self._respond(sock, 200, body, MIME[".json"],
                              extra={"Cache-Control": "no-store"})
                return

            if path == "/robots.txt":
                self._respond(sock, 200, b"User-agent: *\nDisallow: /\n",
                              MIME[".txt"])
                return

            # Room route: /r/<room> serves the chat shell (client-side routing).
            if path == "/" or path.startswith("/r/"):
                return self._serve_file(sock, "index.html", method, cache=False)

            # Static files
            rel = path.lstrip("/")
            if rel.startswith("static/"):
                rel = rel[len("static/"):]
            if ".." in rel or rel.startswith("/") or "\\" in rel:
                status = 400
                self._respond(sock, 400, b"Bad request",
                              "text/plain; charset=utf-8")
                return
            served = self._serve_file(sock, rel, method, cache=True)
            if not served:
                status = 404
                self._respond(sock, 404, b"Not found",
                              "text/plain; charset=utf-8")
            return
        finally:
            if ACCESS_LOG:
                # Deliberately no IP address, no user agent, no body.
                sys.stdout.write(f"{method} {path} -> {status}\n")
                sys.stdout.flush()
            self._safe_close()

    def _serve_file(self, sock, rel, method, cache):
        full = os.path.join(STATIC_DIR, rel)
        full = os.path.abspath(full)
        if not full.startswith(os.path.abspath(STATIC_DIR)):
            return False
        if not os.path.isfile(full):
            return False
        ext = os.path.splitext(full)[1].lower()
        ctype = MIME.get(ext, "application/octet-stream")
        try:
            with open(full, "rb") as fh:
                body = fh.read()
        except OSError:
            return False
        extra = {}
        if cache:
            extra["Cache-Control"] = "public, max-age=3600"
        else:
            extra["Cache-Control"] = "no-cache"
        self._respond(sock, 200, body, ctype, extra=extra,
                      head_only=(method == "HEAD"))
        return True

    def _respond(self, sock, status, body, ctype, extra=None, head_only=False):
        try:
            phrase = HTTPStatus(status).phrase
        except ValueError:
            phrase = "OK"
        headers = [
            f"HTTP/1.1 {status} {phrase}",
            f"Content-Type: {ctype}",
            f"Content-Length: {len(body)}",
            "X-Content-Type-Options: nosniff",
            "X-Frame-Options: DENY",
            "Referrer-Policy: no-referrer",
            "Permissions-Policy: geolocation=(), microphone=(), camera=()",
            "Cross-Origin-Opener-Policy: same-origin",
            "Strict-Transport-Security: max-age=31536000; includeSubDomains",
            "Content-Security-Policy: default-src 'self'; connect-src 'self' ws: wss:; img-src 'self' data:; style-src 'self'; script-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'",
            "Connection: close",
        ]
        for k, v in (extra or {}).items():
            headers.append(f"{k}: {v}")
        head = ("\r\n".join(headers) + "\r\n\r\n").encode("latin-1")
        try:
            sock.sendall(head if head_only else head + body)
        except OSError:
            pass

    def _safe_close(self):
        try:
            self.request.close()
        except Exception:
            pass


class ThreadedServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True
    request_queue_size = 128

    def handle_error(self, request, client_address):
        # Never print a traceback containing a client address.
        pass


# --------------------------------------------------------------------------
# Background maintenance
# --------------------------------------------------------------------------


def janitor():
    while True:
        time.sleep(60)
        try:
            reap_idle_rooms()
        except Exception:
            pass


def main():
    if not os.path.isdir(STATIC_DIR):
        print(f"FATAL: static dir not found: {STATIC_DIR}", file=sys.stderr)
        return 1

    server = ThreadedServer((HOST, PORT), Handler)

    stop = threading.Event()

    def shutdown(signum, frame):
        if stop.is_set():
            return
        stop.set()
        print("\nShutting down — all rooms and messages are being erased.", flush=True)
        threading.Thread(target=server.shutdown, daemon=True).start()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, shutdown)
        except (ValueError, OSError):
            pass

    threading.Thread(target=janitor, daemon=True).start()

    print(f"anonchat listening on http://{HOST}:{PORT}")
    print("mode: in-memory only · no disk writes · no IP logging")
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
