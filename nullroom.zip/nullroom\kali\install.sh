#!/usr/bin/env bash
# nullroom — installer for Kali Linux / Debian / Ubuntu.
# No dependencies, no pip, no sudo needed for the user-level install.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="${HOME}/.local/bin"
APP_DIR="${HOME}/.local/share/nullroom"

echo "nullroom installer"
echo "------------------"

# 1. Python check
if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 not found. Install it with:  sudo apt install -y python3"
  exit 1
fi
PYV="$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
echo "python3 $PYV found"

# 2. Dependency check — there should be none.
python3 - <<'PY'
import sys
mods = ["socket", "ssl", "select", "termios", "tty", "json", "shutil",
        "unicodedata", "threading", "subprocess", "urllib.request"]
missing = [m for m in mods if __import__(m) is None]
sys.exit(0 if not missing else 1)
PY
echo "all required modules present (standard library only)"

# 3. Install files — locked down on purpose.
#
# The client never needs to write to its own code, so its files are
# read-only to everyone (444) and owned by the installing user. Only the
# launcher is executable (755). Result: even if something running as you
# is compromised, the tool itself cannot be rewritten in place — an
# attacker would need to change ownership first, which leaves a trace.
mkdir -p "$APP_DIR" "$BIN_DIR"
install -m 444 "$HERE/client.py" "$APP_DIR/client.py"
install -m 444 "$HERE/tui.py" "$APP_DIR/tui.py"
chown "$(id -u):$(id -g)" "$APP_DIR/client.py" "$APP_DIR/tui.py" 2>/dev/null || true
chmod 444 "$APP_DIR/client.py" "$APP_DIR/tui.py"

cat > "$BIN_DIR/nullroom" <<EOF
#!/usr/bin/env bash
exec python3 "$APP_DIR/client.py" "\$@"
EOF
chmod 755 "$BIN_DIR/nullroom"

echo "installed: $APP_DIR"
echo "launcher : $BIN_DIR/nullroom"
echo

# 4. Verify the permissions we just set — and show them, so the user
#    sees proof instead of taking our word for it.
echo "permissions (read-only code, executable launcher):"
ls -l "$APP_DIR/client.py" "$APP_DIR/tui.py" "$BIN_DIR/nullroom"

# 5. PATH hint
case ":$PATH:" in
  *":$BIN_DIR:"*) ;;
  *)
    echo
    echo "Add this to your shell rc (~/.zshrc or ~/.bashrc):"
    echo "    export PATH=\"\$HOME/.local/bin:\$PATH\""
    ;;
esac

echo
echo "Run it:"
echo "    nullroom --server chat.example.com --room kali"
echo
echo "Privacy: the client keeps nothing but a config file with your"
echo "preferred server and theme (~/.config/nullroom/config.json)."
echo "Transcripts are written only when you ask with /save."
