/* nullroom client. No dependencies, no analytics, no external requests.
   Identity is chosen per tab and held only in memory — a reload is a new person. */
(function () {
  "use strict";

  var $ = function (id) { return document.getElementById(id); };

  var els = {
    landing: $("view-landing"), chat: $("view-chat"),
    createForm: $("create-form"), roomInput: $("room-input"),
    roomList: $("room-list"), refresh: $("refresh-rooms"),
    roomTitle: $("room-title"), roomMeta: $("room-meta"),
    conn: $("conn"), leave: $("leave-btn"), back: document.querySelector(".back"),
    messages: $("messages"), typing: $("typing"),
    sendForm: $("send-form"), msgInput: $("msg-input"), sendBtn: $("send-btn"),
    counter: $("counter"), limit: $("limit"), nickDisplay: $("nick-display"),
    toast: $("toast"),
    inviteBtn: $("invite-btn"), invitePanel: $("invite-panel"),
    inviteBox: $("invite-box"), copyInvite: $("copy-invite"),
    lockBtn: $("lock-btn"), rotateBtn: $("rotate-btn")
  };

  var state = {
    room: null, ws: null, nick: null, limits: { max_chars: 1000 },
    reconnectDelay: 600, reconnectTimer: null, intentional: false,
    typingTimer: null, lastTypingSent: 0, peers: {}, lastDay: null,
    roomId: null, lockKey: null, locked: false, topic: "", owner: ""
  };

  var ADJ = ["quiet", "loud", "slow", "fast", "grey", "amber", "violet", "hollow",
             "bitter", "gentle", "sharp", "wandering", "static", "distant", "ashen",
             "paper", "iron", "salt", "neon", "pale"];
  var NOUN = ["fox", "crow", "moth", "heron", "otter", "wren", "lynx", "hare",
              "raven", "koi", "ibis", "seal", "stork", "newt", "finch", "puma"];

  function randomNick() {
    var a = ADJ[Math.floor(Math.random() * ADJ.length)];
    var n = NOUN[Math.floor(Math.random() * NOUN.length)];
    var d = Math.floor(Math.random() * 90) + 10;
    return a + "-" + n + "-" + d;
  }

  function toast(text, ms) {
    els.toast.textContent = text;
    els.toast.classList.remove("hidden");
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { els.toast.classList.add("hidden"); }, ms || 3200);
  }

  function esc(s) { return s; } // we never use innerHTML for user data

  function clockTime(ms) {
    var d = new Date(ms);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }

  function dayKey(ms) {
    var d = new Date(ms);
    return d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate();
  }

  function dayLabel(ms) {
    var d = new Date(ms), t = new Date();
    if (dayKey(ms) === dayKey(t.getTime())) return "Today";
    var y = new Date(t.getTime() - 86400000);
    if (dayKey(ms) === dayKey(y.getTime())) return "Yesterday";
    return d.toLocaleDateString([], { month: "short", day: "numeric" });
  }

  function maybeDaySep(ts) {
    var k = dayKey(ts);
    if (k === state.lastDay) return;
    state.lastDay = k;
    var sep = document.createElement("div");
    sep.className = "daysep";
    sep.appendChild(document.createTextNode(dayLabel(ts)));
    els.messages.appendChild(sep);
  }

  function atBottom() {
    var m = els.messages;
    return m.scrollHeight - m.scrollTop - m.clientHeight < 120;
  }

  function scrollDown(force) {
    if (force || atBottom()) els.messages.scrollTop = els.messages.scrollHeight;
  }

  function addMessage(item, mine) {
    maybeDaySep(item.ts);
    var wrap = document.createElement("div");
    wrap.className = "msg" + (mine ? " mine" : "");
    var who = document.createElement("span");
    who.className = "who";
    who.textContent = item.nick;
    var body = document.createElement("span");
    body.className = "body";
    body.textContent = esc(item.text);
    var when = document.createElement("span");
    when.className = "when";
    when.textContent = clockTime(item.ts);
    wrap.appendChild(who);
    wrap.appendChild(body);
    wrap.appendChild(when);
    var stick = atBottom();
    els.messages.appendChild(wrap);
    scrollDown(stick);
  }

  function addNotice(text, cls) {
    var d = document.createElement("div");
    d.className = cls || "sys";
    d.textContent = text;
    els.messages.appendChild(d);
    scrollDown(true);
  }

  // ── rooms list ───────────────────────────────────────────
  function loadRooms() {
    fetch("/api/rooms", { cache: "no-store", credentials: "omit" })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        els.roomList.textContent = "";
        var rooms = (data && data.rooms) || [];
        if (!rooms.length) {
          var li = document.createElement("li");
          li.className = "empty";
          li.textContent = "No live rooms yet. Create the first one above.";
          els.roomList.appendChild(li);
          return;
        }
        rooms.forEach(function (r) {
          var li = document.createElement("li");
          var a = document.createElement("a");
          a.href = "/r/" + encodeURIComponent(r.name);
          var name = document.createElement("span");
          name.className = "rname";
          name.textContent = "#" + r.name;
          var topic = document.createElement("span");
          topic.className = "rtopic";
          topic.textContent = r.topic || "";
          var users = document.createElement("span");
          users.className = "rusers";
          users.textContent = r.users + (r.users === 1 ? " person" : " people");
          a.appendChild(name); a.appendChild(topic); a.appendChild(users);
          li.appendChild(a);
          els.roomList.appendChild(li);
        });
      })
      .catch(function () {
        els.roomList.textContent = "";
        var li = document.createElement("li");
        li.className = "empty";
        li.textContent = "Could not reach the server.";
        els.roomList.appendChild(li);
      });
  }

  // ── routing ──────────────────────────────────────────────
  function parseRoom() {
    // /r/<name>            — join by name (create on demand)
    // /r/<name>?id=xxxxxx  — join by id, resolved server-side
    var m = location.pathname.match(/^\/r\/([a-z0-9-]{2,32})\/?$/i);
    if (!m) return null;
    var q = new URLSearchParams(location.search);
    return {
      name: m[1].toLowerCase(),
      id: (q.get("id") || "").toLowerCase() || null,
      key: q.get("key") || null
    };
  }

  function wsPath(room) {
    var p = "/ws/" + encodeURIComponent(room.name);
    var parts = [];
    if (room.id) parts.push("id=" + encodeURIComponent(room.id));
    if (room.key) parts.push("key=" + encodeURIComponent(room.key));
    return parts.length ? p + "?" + parts.join("&") : p;
  }

  // A pasted invite string: host/room?id=xxxxxx[&key=...]
  // or just the six characters of an id.
  function parseInviteInput(text) {
    text = text.trim().split(/\s+/).pop();
    if (/^[23456789abcdefghjkmnpqrstuvwxyz]{6}$/.test(text.toLowerCase())) {
      return { room: "lobby", id: text.toLowerCase(), key: null };
    }
    var rest = text.indexOf("://") !== -1 ? text.split("://")[1] : text;
    if (rest.indexOf("/") === -1 || rest.indexOf("?") === -1) return null;
    var frag = rest.split("?")[1];
    var params = {};
    frag.split("&").forEach(function (pair) {
      var kv = pair.split("=");
      if (kv.length === 2) params[kv[0]] = decodeURIComponent(kv[1]);
    });
    var room = rest.split("?")[0].split("/").pop().replace(/\/$/, "").toLowerCase();
    if (!/^[a-z0-9-]{2,32}$/.test(room)) room = "lobby";
    var id = (params.id || "").toLowerCase();
    if (!/^[23456789abcdefghjkmnpqrstuvwxyz]{6}$/.test(id)) return null;
    return { room: room, id: id, key: params.key || null };
  }

  function showLanding() {
    els.chat.classList.add("hidden");
    els.landing.classList.remove("hidden");
    document.title = "nullroom — anonymous rooms";
    loadRooms();
  }

  function showChat(room) {
    els.landing.classList.add("hidden");
    els.chat.classList.remove("hidden");
    els.roomTitle.textContent = room.name;
    document.title = "#" + room.name + " — nullroom";
    els.messages.textContent = "";
    state.lastDay = null;
    state.peers = {};
    connect(room);
  }

  // ── websocket ────────────────────────────────────────────
  function wsURL(room) {
    var proto = location.protocol === "https:" ? "wss:" : "ws:";
    return proto + "//" + location.host + wsPath(room);
  }

  function setConn(stateName, label) {
    els.conn.dataset.state = stateName;
    els.conn.textContent = label;
  }

  function connect(room) {
    state.room = room;
    if (room.id) state.roomId = room.id;
    if (room.key) state.lockKey = room.key;
    if (els.invitePanel) els.invitePanel.classList.add("hidden");
    state.intentional = false;
    if (!state.nick) {
      state.nick = randomNick();
      els.nickDisplay.textContent = state.nick;
    }
    setConn("connecting", "connecting");

    var ws;
    try { ws = new WebSocket(wsURL(room)); }
    catch (e) { setConn("closed", "offline"); return; }
    state.ws = ws;

    ws.onopen = function () {
      state.reconnectDelay = 600;
      setConn("open", "live");
      send({ t: "hello", nick: state.nick });
      els.msgInput.focus();
    };

    ws.onmessage = function (ev) {
      var m;
      try { m = JSON.parse(ev.data); } catch (e) { return; }

      if (m.t === "welcome") {
        state.nick = m.nick;
        state.limits = m.limits || state.limits;
        els.nickDisplay.textContent = state.nick;
        els.limit.textContent = state.limits.max_chars;
        els.msgInput.maxLength = state.limits.max_chars;
        if (m.room) { absorbRoom(m.room); }
      } else if (m.t === "joined") {
        if (m.room) { absorbRoom(m.room); }
      } else if (m.t === "backlog") {
        (m.items || []).forEach(function (it) { addMessage(it, it.nick === state.nick); });
        addNotice("— history is kept in memory only and vanishes when the room empties —");
        scrollDown(true);
      } else if (m.t === "msg") {
        addMessage(m, m.nick === state.nick);
      } else if (m.t === "sys") {
        addNotice(m.text);
        if (/created this room/.test(m.text)) {
          send({ t: "id" });
          toast("Room created — press Invite to share it.");
        }
      } else if (m.t === "room-id") {
        absorbRoom({ name: m.name, id: m.id, locked: m.locked, owner: m.owner });
        if (m.rotated) { toast("New room id: " + m.id, 6000); }
        renderInvite();
      } else if (m.t === "lock-state") {
        state.locked = !!m.locked;
        renderInvite();
      } else if (m.t === "topic") {
        state.topic = m.topic || "";
        renderInvite();
      } else if (m.t === "closed") {
        addNotice("This room was closed (" + (m.reason || "no reason given") + ").");
        toast("Room closed — pick another.");
        state.roomId = null;
        if (els.invitePanel) els.invitePanel.classList.add("hidden");
      } else if (m.t === "err") {
        addNotice(m.text, "err");
      } else if (m.t === "typing") {
        state.peers[m.nick] = Date.now();
        renderTyping();
      }
    };

    ws.onclose = function () {
      setConn("closed", "offline");
      if (state.intentional) return;
      clearTimeout(state.reconnectTimer);
      state.reconnectTimer = setTimeout(function () {
        var current = parseRoom();
        if (current && state.room && current.name === state.room.name) {
          connect(current);
        }
      }, state.reconnectDelay);
      state.reconnectDelay = Math.min(state.reconnectDelay * 1.8, 12000);
    };

    ws.onerror = function () { /* onclose handles it */ };
  }

  function send(obj) {
    if (state.ws && state.ws.readyState === 1) {
      state.ws.send(JSON.stringify(obj));
      return true;
    }
    return false;
  }

  function inviteTarget() {
    var proto = location.protocol === "https:" ? "wss" : "ws";
    var path = location.protocol === "https:" ? "/r/" : "/r/";
    var url = location.origin + path + (state.room ? state.room.name : "");
    var parts = [];
    if (state.roomId) parts.push("id=" + state.roomId);
    if (state.lockKey) parts.push("key=" + state.lockKey);
    return parts.length ? url + "?" + parts.join("&") : url;
  }

  function renderInvite() {
    if (!els.inviteBox) return;
    var lines = [];
    lines.push("room   " + (state.room ? "#" + state.room.name : "?"));
    lines.push("id     " + (state.roomId || "(pending)"));
    if (state.locked) lines.push("locked yes");
    if (state.topic) lines.push("topic  " + state.topic);
    lines.push("");
    lines.push(inviteTarget());
    els.inviteBox.textContent = lines.join("\n");
  }

  function absorbRoom(r) {
    if (!r) return;
    if (r.name) state.room.name = r.name;
    if (r.id) state.roomId = r.id;
    if (r.topic !== undefined) state.topic = r.topic || "";
    if (r.locked !== undefined) state.locked = !!r.locked;
    if (r.owner !== undefined) state.owner = r.owner || "";
    if (r.users !== undefined) els.roomMeta.textContent = r.users + " here";
    if (r.name) {
      els.roomTitle.textContent = r.name;
      document.title = "#" + r.name + " — nullroom";
    }
  }

  function renderTyping() {
    var cutoff = Date.now() - 4000, names = [];
    Object.keys(state.peers).forEach(function (n) {
      if (state.peers[n] < cutoff) delete state.peers[n];
      else if (n !== state.nick) names.push(n);
    });
    if (!names.length) { els.typing.textContent = ""; return; }
    els.typing.textContent = names.slice(0, 3).join(", ") +
      (names.length > 3 ? " and others are" : (names.length === 1 ? " is" : " are")) + " typing…";
  }
  setInterval(renderTyping, 1200);

  // ── events ───────────────────────────────────────────────
  els.createForm.addEventListener("submit", function (e) {
    e.preventDefault();
    var name = (els.roomInput.value || "").trim().toLowerCase()
      .replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "").replace(/^-+|-+$/g, "");
    if (name.length < 2) { toast("Room name needs at least 2 characters."); return; }
    history.pushState({}, "", "/r/" + name);
    route();
  });

  els.refresh.addEventListener("click", loadRooms);

  els.createForm.addEventListener("submit", function (e) {
    e.preventDefault();
    var raw = (els.roomInput.value || "").trim();
    // A pasted id or invite jumps straight into the room.
    if (raw) {
      var pinv = parseInviteInput(raw);
      if (pinv) {
        var url = "/r/" + pinv.room +
          "?id=" + pinv.id + (pinv.key ? "&key=" + pinv.key : "");
        history.pushState({}, "", url);
        route();
        return;
      }
    }
    var name = raw.toLowerCase()
      .replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "").replace(/^-+|-+$/g, "");
    if (name.length < 2) { toast("Room name needs at least 2 characters."); return; }
    history.pushState({}, "", "/r/" + name);
    route();
  });

  els.inviteBtn.addEventListener("click", function () {
    var panel = els.invitePanel;
    var opening = panel.classList.contains("hidden");
    panel.classList.toggle("hidden");
    if (opening) { send({ t: "id" }); renderInvite(); }
  });

  els.copyInvite.addEventListener("click", function () {
    var text = els.inviteBox.textContent;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(
        function () { toast("Invite copied."); },
        function () { toast("Select the invite and copy it manually."); }
      );
    } else {
      toast("Select the invite and copy it manually.");
    }
  });

  els.lockBtn.addEventListener("click", function () {
    var key = window.prompt("Lock key (leave empty to unlock):", state.lockKey || "");
    if (key === null) return;
    state.lockKey = key || null;
    if (!send({ t: "lock", key: key })) { toast("Not connected."); return; }
  });

  els.rotateBtn.addEventListener("click", function () {
    if (!send({ t: "rotate-id" })) { toast("Not connected."); return; }
  });

  els.sendForm.addEventListener("submit", function (e) {
    e.preventDefault();
    var text = els.msgInput.value.trim();
    if (!text) return;
    if (!send({ t: "msg", text: text, nick: state.nick })) {
      toast("Not connected — reconnecting…");
      return;
    }
    els.msgInput.value = "";
    els.counter.textContent = "0";
  });

  els.msgInput.addEventListener("input", function () {
    els.counter.textContent = els.msgInput.value.length;
    var now = Date.now();
    if (now - state.lastTypingSent > 2500 && els.msgInput.value) {
      state.lastTypingSent = now;
      send({ t: "typing" });
    }
  });

  els.msgInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      els.sendForm.dispatchEvent(new Event("submit", { cancelable: true }));
    }
  });

  function leave() {
    state.intentional = true;
    clearTimeout(state.reconnectTimer);
    if (state.ws) { try { state.ws.close(1000); } catch (e) {} }
    history.pushState({}, "", "/");
    route();
  }
  els.leave.addEventListener("click", leave);
  els.back.addEventListener("click", function (e) { e.preventDefault(); leave(); });

  window.addEventListener("popstate", route);
  window.addEventListener("beforeunload", function () {
    state.intentional = true;
    if (state.ws) { try { state.ws.close(1000); } catch (e) {} }
  });

  function route() {
    var room = parseRoom();
    if (room) {
      if (state.ws) { state.intentional = true; try { state.ws.close(1000); } catch (e) {} }
      showChat(room);
    } else {
      if (state.ws) { state.intentional = true; try { state.ws.close(1000); } catch (e) {} }
      state.ws = null;
      showLanding();
    }
  }

  route();
})();
