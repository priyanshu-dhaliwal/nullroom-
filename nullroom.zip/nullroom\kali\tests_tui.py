"""Headless test of the TUI's pure logic — no terminal required.

Verifies the pieces that are easy to get wrong and expensive to debug
on a live terminal: display-width maths, wrapping, truncation, input
line editing, history, and URL/room-name parsing.

Run: python3 tests_tui.py
"""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import tui
from client import parse_ws_url, random_handle, App, clock


class TestWidth(unittest.TestCase):
    def test_ascii_width(self):
        self.assertEqual(tui.display_width("hello"), 5)

    def test_wide_chars(self):
        # CJK characters occupy two cells each.
        self.assertEqual(tui.display_width("日本語"), 6)

    def test_combining_marks_are_zero_width(self):
        # "e" + combining acute
        self.assertEqual(tui.display_width("e\u0301"), 1)

    def test_empty(self):
        self.assertEqual(tui.display_width(""), 0)


class TestTruncate(unittest.TestCase):
    def test_short_passthrough(self):
        self.assertEqual(tui.truncate("abc", 10), "abc")

    def test_cut_adds_ellipsis(self):
        out = tui.truncate("abcdefghij", 5)
        self.assertLessEqual(tui.display_width(out), 5)
        self.assertTrue(out.endswith("…"))

    def test_exact_fit_no_ellipsis(self):
        self.assertEqual(tui.truncate("abcde", 5), "abcde")

    def test_wide_char_never_overflows(self):
        out = tui.truncate("日本語日本語", 5)
        self.assertLessEqual(tui.display_width(out), 5)

    def test_zero_width(self):
        self.assertEqual(tui.truncate("abc", 0), "")


class TestWrap(unittest.TestCase):
    def test_wraps_on_spaces(self):
        lines = tui.wrap("one two three four", 10)
        self.assertTrue(all(tui.display_width(l) <= 10 for l in lines))
        self.assertEqual(" ".join(lines), "one two three four")

    def test_preserves_newlines(self):
        lines = tui.wrap("a\nb", 20)
        self.assertEqual(lines, ["a", "b"])

    def test_blank_line_kept(self):
        lines = tui.wrap("a\n\nb", 20)
        self.assertEqual(lines, ["a", "", "b"])

    def test_long_token_hard_split(self):
        lines = tui.wrap("x" * 25, 10)
        self.assertTrue(all(tui.display_width(l) <= 10 for l in lines))
        self.assertEqual("".join(lines), "x" * 25)

    def test_url_like_token(self):
        url = "https://example.com/" + "a" * 40
        lines = tui.wrap(url, 20)
        self.assertTrue(all(tui.display_width(l) <= 20 for l in lines))


class TestInputLine(unittest.TestCase):
    def setUp(self):
        self.ui = tui.UI()

    def test_insert_and_take(self):
        self.ui.insert_text("hello")
        self.assertEqual(self.ui.take_input(), "hello")
        self.assertEqual(self.ui.input_buf, [])

    def test_take_strips_and_ignores_empty(self):
        self.ui.insert_text("   ")
        self.assertEqual(self.ui.take_input(), "")

    def test_backspace_at_start_is_safe(self):
        self.ui.backspace()
        self.assertEqual(self.ui.input_buf, [])

    def test_delete_forward(self):
        self.ui.insert_text("abc")
        self.ui.input_cursor = 1
        self.ui.delete_forward()
        self.assertEqual("".join(self.ui.input_buf), "ac")

    def test_cursor_midline_insert(self):
        self.ui.insert_text("ac")
        self.ui.input_cursor = 1
        self.ui.insert_text("b")
        self.assertEqual("".join(self.ui.input_buf), "abc")

    def test_unicode_insert(self):
        self.ui.insert_text("héllo 日本")
        self.assertEqual("".join(self.ui.input_buf), "héllo 日本")

    def test_history_roundtrip(self):
        self.ui.insert_text("first")
        self.ui.take_input()
        self.ui.insert_text("second")
        self.ui.take_input()
        self.ui.history_prev()
        self.assertEqual("".join(self.ui.input_buf), "second")
        self.ui.history_prev()
        self.assertEqual("".join(self.ui.input_buf), "first")
        self.ui.history_next()
        self.assertEqual("".join(self.ui.input_buf), "second")
        self.ui.history_next()
        self.assertEqual("".join(self.ui.input_buf), "")

    def test_history_prev_on_empty_is_safe(self):
        self.ui.history_prev()
        self.assertEqual(self.ui.input_buf, [])


class TestUrlParsing(unittest.TestCase):
    def test_bare_host_defaults_to_lobby(self):
        scheme, host, port, path = parse_ws_url("chat.example.com")
        self.assertEqual(scheme, "ws")
        self.assertEqual(host, "chat.example.com")
        self.assertEqual(port, 80)
        self.assertEqual(path, "/ws/lobby")

    def test_host_port(self):
        _, host, port, _ = parse_ws_url("127.0.0.1:8080")
        self.assertEqual((host, port), ("127.0.0.1", 8080))

    def test_wss_default_port(self):
        scheme, _, port, _ = parse_ws_url("wss://chat.example.com")
        self.assertEqual(scheme, "wss")
        self.assertEqual(port, 443)

    def test_path_room(self):
        _, _, _, path = parse_ws_url("ws://host:8080/kali")
        self.assertEqual(path, "/ws/kali")

    def test_explicit_ws_path(self):
        _, _, _, path = parse_ws_url("ws://host:8080/ws/kali")
        self.assertEqual(path, "/ws/kali")

    def test_no_scheme_with_path(self):
        scheme, host, port, path = parse_ws_url("host:9000/room1")
        self.assertEqual((scheme, host, port, path), ("ws", "host", 9000, "/ws/room1"))


class TestHandle(unittest.TestCase):
    def test_shape(self):
        h = random_handle()
        parts = h.split("-")
        self.assertEqual(len(parts), 3)
        self.assertTrue(parts[2].isdigit())

    def test_unique_enough(self):
        seen = {random_handle() for _ in range(50)}
        self.assertGreater(len(seen), 40)


class TestAppLogic(unittest.TestCase):
    """App methods that do not need a socket or a terminal."""

    def make_app(self):
        app = App.__new__(App)
        app.handle = "quiet-fox-42"
        app.room = "kali"
        app.room_users = 3
        app.tabs = ["#kali"]
        app.tab = 0
        app.buffers = {"#kali": []}
        app.room_ids = {}
        app.room_id = None
        app.room_lock_key = None
        app.owned_rooms = {}
        app.unread = {}
        app.typing = {}
        app.transcript = []
        app.last_mention_notify = 0
        app.mention_sound = False
        app.notify_enabled = False
        app.limits = {"max_chars": 1000}
        app.connected = False
        app.ws = None
        app.view = "chat"
        app.server = "ws://127.0.0.1:8080"
        app.search_hits = []
        app.search_index = 0
        app.filter_query = ""
        app.rooms = []
        app.rooms_selected = 0
        app.overlay = None
        app.ui = tui.UI()
        return app

    def test_mention_detection(self):
        app = self.make_app()
        self.assertTrue(app.mention_of_me("hey quiet-fox-42 look"))
        self.assertTrue(app.mention_of_me("HEY QUIET-FOX-42"))
        self.assertTrue(app.mention_of_me("@quiet check this"))
        self.assertFalse(app.mention_of_me("hello everyone"))

    def test_membership_tracking(self):
        app = self.make_app()
        app.track_membership("loud-crow-11 joined")
        self.assertEqual(app.room_users, 4)
        app.track_membership("loud-crow-11 left")
        self.assertEqual(app.room_users, 3)

    def test_own_join_does_not_double_count(self):
        app = self.make_app()
        app.track_membership("quiet-fox-42 joined")
        self.assertEqual(app.room_users, 3)

    def test_membership_never_negative(self):
        app = self.make_app()
        app.room_users = 0
        app.track_membership("ghost-owl-9 left")
        self.assertEqual(app.room_users, 0)

    def test_search_finds_hits(self):
        app = self.make_app()
        app.buffers["#kali"] = [
            {"kind": "msg", "nick": "a", "text": "hello world"},
            {"kind": "msg", "nick": "b", "text": "goodbye"},
        ]
        app.do_search("hello")
        self.assertEqual(len(app.search_hits), 1)

    def test_next_hit_wraps(self):
        app = self.make_app()
        app.buffers["#kali"] = [{"text": "x"} for _ in range(4)]
        app.do_search("x")
        self.assertEqual(len(app.search_hits), 4)
        for _ in range(5):
            app.next_hit()
        self.assertLess(app.search_index, 4)

    def test_typing_window(self):
        import time as _t
        app = self.make_app()
        app.typing = {"a": _t.time(), "b": _t.time() - 99}
        self.assertIn("a", app.typing_now())
        self.assertNotIn("b", app.typing_now())

    def test_tab_cycling(self):
        app = self.make_app()
        app.tabs = ["#kali", "#general", "@someone"]
        app.buffers = {t: [] for t in app.tabs}
        app.tab = 0
        app.next_tab()
        self.assertEqual(app.current_tab(), "#general")
        app.prev_tab()
        self.assertEqual(app.current_tab(), "#kali")

    def test_owns_current_room_only_for_created(self):
        app = self.make_app()
        app.room = "mine"
        app.owned_rooms = {}
        self.assertFalse(app.owns_current_room())
        app.owned_rooms = {"#mine": {"id": "abc234", "topic": ""}}
        self.assertTrue(app.owns_current_room())

    def test_theme_cycles_through_all(self):
        app = self.make_app()
        app.theme_name = "dark"
        app.theme = {}
        for _ in range(len(THEMES_KEYS)):
            app.cycle_theme()
        self.assertIn(app.theme_name, THEMES_KEYS)

    def test_join_rejects_bad_names(self):
        app = self.make_app()
        app.join_room("bad name!!")
        self.assertEqual(app.room, "kali")   # unchanged

    def test_join_accepts_good_name(self):
        app = self.make_app()
        app.room = "kali"
        app.ws = None
        app.join_room("#new-room")
        self.assertEqual(app.room, "new-room")

    def test_join_by_id_uses_id_not_name(self):
        app = self.make_app()
        app.ws = None
        app.join_room("k6bb4h", room_id="k6bb4h")
        self.assertEqual(app.room_id, "k6bb4h")


from client import THEMES as THEMES_MAP  # noqa: E402
THEMES_KEYS = list(THEMES_MAP)


if __name__ == "__main__":
    unittest.main(verbosity=2)
