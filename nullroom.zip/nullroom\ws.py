"""
Minimal RFC6455 WebSocket implementation on the Python standard library.

Deliberately dependency-free so the whole app runs on a bare Python 3.9+
interpreter with nothing installed. Handles text frames, ping/pong,
close, fragmentation, and UTF-8 validation. No permessage-deflate
(we do not negotiate it, so peers must not send compressed frames).
"""

import base64
import hashlib
import os
import socket
import struct
import threading

GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

OP_CONT = 0x0
OP_TEXT = 0x1
OP_BIN = 0x2
OP_CLOSE = 0x8
OP_PING = 0x9
OP_PONG = 0xA

MAX_FRAME = 1 << 20  # 1 MiB hard cap on a single frame


class WSError(Exception):
    pass


class WSClosed(Exception):
    pass


class WebSocket:
    is_server = True

    def __init__(self, sock, max_message=64 * 1024, is_server=True):
        self.sock = sock
        self.max_message = max_message
        self.is_server = is_server
        self._send_lock = threading.Lock()
        self._buf = b""
        self.closed = False

    # ---------- handshake ----------

    @staticmethod
    def accept(sock, headers):
        key = headers.get("sec-websocket-key")
        if not key:
            raise WSError("missing Sec-WebSocket-Key")
        ver = headers.get("sec-websocket-version", "")
        if ver != "13":
            raise WSError("unsupported websocket version")
        accept_val = base64.b64encode(
            hashlib.sha1((key + GUID).encode("ascii")).digest()
        ).decode("ascii")
        resp = (
            "HTTP/1.1 101 Switching Protocols\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            f"Sec-WebSocket-Accept: {accept_val}\r\n"
            "\r\n"
        )
        sock.sendall(resp.encode("ascii"))
        return WebSocket(sock, max_message=getattr(sock, "_max_message", 64 * 1024),
                         is_server=True)

    # ---------- raw io ----------

    def _recv_exact(self, n):
        while len(self._buf) < n:
            try:
                chunk = self.sock.recv(65536)
            except (ConnectionResetError, OSError):
                raise WSClosed()
            if not chunk:
                raise WSClosed()
            self._buf += chunk
        out, self._buf = self._buf[:n], self._buf[n:]
        return out

    def _read_frame(self):
        b1, b2 = self._recv_exact(2)
        fin = bool(b1 & 0x80)
        rsv = b1 & 0x70
        opcode = b1 & 0x0F
        masked = bool(b2 & 0x80)
        length = b2 & 0x7F
        if rsv:
            raise WSError("reserved bits set")
        if length == 126:
            (length,) = struct.unpack("!H", self._recv_exact(2))
        elif length == 127:
            (length,) = struct.unpack("!Q", self._recv_exact(8))
        if length > MAX_FRAME:
            raise WSError("frame too large")
        # RFC6455 frame masking is directional: a server MUST NOT mask
        # frames it sends, and MUST reject masked frames from a client.
        if self.is_server and not masked:
            raise WSError("unmasked client frame")
        if not self.is_server and masked:
            raise WSError("server frame must not be masked")
        mask = self._recv_exact(4) if masked else b""
        payload = bytearray(self._recv_exact(length))
        if masked:
            for i in range(length):
                payload[i] ^= mask[i & 3]
        return fin, opcode, bytes(payload)

    # ---------- public api ----------

    def recv(self):
        """Return the next text message as str. Raises WSClosed when done."""
        message = bytearray()
        message_op = None
        while True:
            fin, opcode, payload = self._read_frame()

            if opcode == OP_CLOSE:
                try:
                    self.send_frame(OP_CLOSE, payload[:2])
                except Exception:
                    pass
                raise WSClosed()
            if opcode == OP_PING:
                self.send_frame(OP_PONG, payload)
                continue
            if opcode == OP_PONG:
                continue
            if opcode in (OP_TEXT, OP_BIN):
                if message_op is not None:
                    raise WSError("new data frame during fragmented message")
                if opcode == OP_BIN:
                    raise WSError("binary frames not accepted")
                message_op = opcode
            elif opcode == OP_CONT:
                if message_op is None:
                    raise WSError("continuation without start")
            else:
                raise WSError("unknown opcode")

            message += payload
            if len(message) > self.max_message:
                raise WSError("message too large")
            if fin:
                try:
                    return message.decode("utf-8")
                except UnicodeDecodeError:
                    raise WSError("invalid utf-8")

    def send_frame(self, opcode, payload=b""):
        if self.closed:
            raise WSClosed()
        header = bytearray()
        header.append(0x80 | opcode)
        n = len(payload)
        if n < 126:
            header.append(n)
        elif n < (1 << 16):
            header.append(126)
            header += struct.pack("!H", n)
        else:
            header.append(127)
            header += struct.pack("!Q", n)
        if not self.is_server:
            # A client masks every frame it sends; the server must not.
            mask = os.urandom(4)
            header[1] |= 0x80
            masked = bytes(b ^ mask[i & 3] for i, b in enumerate(payload))
            frame = bytes(header) + mask + masked
        else:
            frame = bytes(header) + payload
        with self._send_lock:
            try:
                self.sock.sendall(frame)
            except OSError:
                self.closed = True
                raise WSClosed()

    def send(self, text):
        self.send_frame(OP_TEXT, text.encode("utf-8"))

    def ping(self):
        self.send_frame(OP_PING, os.urandom(4))

    def close(self, code=1000, reason=b""):
        if self.closed:
            return
        try:
            self.send_frame(OP_CLOSE, struct.pack("!H", code) + reason)
        except Exception:
            pass
        self.closed = True
        try:
            self.sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        try:
            self.sock.close()
        except Exception:
            pass
