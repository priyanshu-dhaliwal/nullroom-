"""
tui.py — a full-screen terminal client for nullroom, built for Kali.

Standard library only: no ncurses binding, no pip install. It draws with
ANSI escapes and reads keys from raw stdin, which works on any Linux
terminal, over SSH, and inside tmux.

Layout
  ┌ header ──────────────────────────────── status ┐
  │ room list / chat panes                          │
  ├ input ──────────────────────────────────────────┤
  └ help ───────────────────────────────────────────┘

Public surface used by client.py:
    class UI  — init/close, size, panes, status, log, input line, key read
"""

import os
import shutil
import sys
import unicodedata

# ── ANSI ────────────────────────────────────────────────────────────────
ESC = "\x1b"
CSI = ESC + "["
RESET = CSI + "0m"


def fg(n):
    return CSI + "38;5;%dm" % n


def bg(n):
    return CSI + "48;5;%dm" % n


BOLD = CSI + "1m"
DIM = CSI + "2m"
ITALIC = CSI + "3m"
UNDER = CSI + "4m"

# 256-colour palette
C_BG = 234
C_PANEL = 236
C_BORDER = 240
C_TEXT = 252
C_DIM = 245
C_ACCENT = 79      # teal
C_ACCENT2 = 141    # violet
C_WARN = 215
C_ERR = 203
C_SYS = 244
C_SEL = 238

ALT_SCREEN = CSI + "?1049h"
NORM_SCREEN = CSI + "?1049l"
HIDE_CURSOR = CSI + "?25l"
SHOW_CURSOR = CSI + "?25h"
CLEAR = CSI + "2J"
MOUSE_ON = CSI + "?1000h" + CSI + "?1006h"
MOUSE_OFF = CSI + "?1000l" + CSI + "?1006l"


def wcwidth(ch):
    """Display width of one character: 0, 1 or 2 cells."""
    if ch == "\t":
        return 1
    if unicodedata.combining(ch):
        return 0
    if unicodedata.east_asian_width(ch) in ("W", "F"):
        return 2
    cat = unicodedata.category(ch)
    if cat in ("Cc", "Cf"):
        return 0
    return 1


def display_width(text):
    return sum(wcwidth(c) for c in text)


def truncate(text, width):
    """Cut text to at most `width` display cells, adding an ellipsis."""
    if width <= 0:
        return ""
    if display_width(text) <= width:
        return text
    out = []
    used = 0
    for ch in text:
        w = wcwidth(ch)
        if used + w > width - 1:
            break
        out.append(ch)
        used += w
    return "".join(out) + "…"


def wrap(text, width):
    """Hard-wrap text to `width` cells, honouring explicit newlines."""
    if width <= 1:
        return [text]
    lines = []
    for para in text.split("\n"):
        if not para:
            lines.append("")
            continue
        cur, used = [], 0
        for word in para.split(" "):
            ww = display_width(word)
            if used and used + 1 + ww > width:
                lines.append(" ".join(cur))
                cur, used = [word], ww
            elif not used and ww > width:
                # a single long token: hard split it
                chunk = []
                cw = 0
                for ch in word:
                    if cw + wcwidth(ch) > width:
                        lines.append("".join(chunk))
                        chunk, cw = [ch], wcwidth(ch)
                    else:
                        chunk.append(ch)
                        cw += wcwidth(ch)
                cur, used = ["".join(chunk)], cw
            else:
                cur.append(word)
                used = used + (1 if used else 0) + ww
        if cur:
            lines.append(" ".join(cur))
    return lines


class UI:
    def __init__(self, out=None, inp=None):
        self.out = out or sys.stdout
        self.inp = inp or sys.stdin
        self._saved_term = None
        self.width, self.height = shutil.get_terminal_size((100, 30))
        self.frame_lines = []
        self.input_buf = []
        self.input_cursor = 0
        self.input_prompt = "> "
        self.input_placeholder = ""
        self.history = []
        self.history_pos = None
        self.scroll = 0        # lines scrolled up from the bottom
        self.messages = []     # list of dicts for the chat pane
        self.status_left = ""
        self.status_right = ""
        self.help_text = ""
        self.log_lines = []
        self.mouse = False
        self.spinner = 0

    # ── terminal lifecycle ──────────────────────────────────────────────
    def init(self):
        try:
            import termios
            import tty
            self._saved_term = termios.tcgetattr(self.inp.fileno())
            tty.setraw(self.inp.fileno())
        except Exception:
            self._saved_term = None
        self._write(ALT_SCREEN + CLEAR + HIDE_CURSOR + MOUSE_ON)
        self.mouse = True
        self.resize()

    def close(self):
        self._write((MOUSE_OFF if self.mouse else "") + SHOW_CURSOR + RESET + NORM_SCREEN)
        try:
            if self._saved_term is not None:
                import termios
                termios.tcsetattr(self.inp.fileno(), termios.TCSADRAIN, self._saved_term)
        except Exception:
            pass

    def resize(self):
        self.width, self.height = shutil.get_terminal_size((100, 30))

    def _write(self, s):
        try:
            self.out.write(s)
            self.out.flush()
        except (BrokenPipeError, ValueError):
            pass

    def _at(self, row, col):
        return CSI + "%d;%dH" % (row, col)

    def refresh_size(self):
        self.resize()

    # ── key reading ─────────────────────────────────────────────────────
    def read_key(self, timeout=None):
        """Return a key name: a printable character, or one of
        UP DOWN LEFT RIGHT HOME END PGUP PGDN ENTER BACKSPACE TAB ESC
        DELETE CTRL-C CTRL-D CTRL-L CTRL-R CTRL-N CTRL-P CTRL-U CTRL-W
        RESIZE NONE, or ('MOUSE', x, y, button)."""
        import select
        r, _, _ = select.select([self.inp], [], [], timeout)
        if not r:
            return "NONE"
        try:
            ch = os.read(self.inp.fileno(), 1)
        except OSError:
            return "ESC"
        if not ch:
            return "ESC"
        b = ch.decode("utf-8", "replace")

        if b == "\x1b":
            return self._read_escape()
        if b in ("\r", "\n"):
            return "ENTER"
        if b in ("\x7f", "\b"):
            return "BACKSPACE"
        if b == "\t":
            return "TAB"
        if b == "\x03":
            return "CTRL-C"
        if b == "\x04":
            return "CTRL-D"
        if b == "\x0c":
            return "CTRL-L"
        if b == "\x12":
            return "CTRL-R"
        if b == "\x0e":
            return "CTRL-N"
        if b == "\x10":
            return "CTRL-P"
        if b == "\x15":
            return "CTRL-U"
        if b == "\x17":
            return "CTRL-W"
        if b == "\x01":
            return "CTRL-A"
        if b == "\x05":
            return "CTRL-E"
        if b == "\x1a":
            return "CTRL-Z"
        if b == "\x06":
            return "CTRL-F"
        if b == "\x02":
            return "CTRL-B"
        if ord(b) < 32:
            return "NONE"

        # Multi-byte UTF-8 character: pull the remaining continuation bytes.
        need = 0
        ob = ord(b)
        if ob >= 0xF0:
            need = 3
        elif ob >= 0xE0:
            need = 2
        elif ob >= 0xC0:
            need = 1
        for _ in range(need):
            r, _, _ = select.select([self.inp], [], [], 0.02)
            if not r:
                break
            try:
                b += os.read(self.inp.fileno(), 1).decode("utf-8", "replace")
            except OSError:
                break
        return b

    def _read_escape(self):
        import select
        r, _, _ = select.select([self.inp], [], [], 0.03)
        if not r:
            return "ESC"
        try:
            nxt = os.read(self.inp.fileno(), 1).decode("utf-8", "replace")
        except OSError:
            return "ESC"
        if nxt not in ("[", "O"):
            return "ESC"
        seq = ""
        while True:
            r, _, _ = select.select([self.inp], [], [], 0.03)
            if not r:
                break
            try:
                c = os.read(self.inp.fileno(), 1).decode("utf-8", "replace")
            except OSError:
                break
            seq += c
            if c.isalpha() or c in ("~", "M", "m"):
                break
            if len(seq) > 16:
                break
        table = {
            "A": "UP", "B": "DOWN", "C": "RIGHT", "D": "LEFT",
            "H": "HOME", "F": "END", "Z": "TAB",
            "1~": "HOME", "2~": "INSERT", "3~": "DELETE", "4~": "END",
            "5~": "PGUP", "6~": "PGDN", "7~": "HOME", "8~": "END",
        }
        if seq.startswith("<") and seq.endswith(("M", "m")):
            try:
                body = seq[1:-1]
                parts = body.split(";")
                btn = int(parts[0])
                x = int(parts[1]) if len(parts) > 1 else 0
                y = int(parts[2]) if len(parts) > 2 else 0
                return ("MOUSE", x, y, btn)
            except (ValueError, IndexError):
                return "NONE"
        return table.get(seq, "NONE")

    # ── input line editing ──────────────────────────────────────────────
    def insert_text(self, text):
        for ch in text:
            if ch == "\n":
                continue
            self.input_buf.insert(self.input_cursor, ch)
            self.input_cursor += 1

    def backspace(self):
        if self.input_cursor > 0:
            del self.input_buf[self.input_cursor - 1]
            self.input_cursor -= 1

    def delete_forward(self):
        if self.input_cursor < len(self.input_buf):
            del self.input_buf[self.input_cursor]

    def clear_input(self):
        self.input_buf = []
        self.input_cursor = 0

    def take_input(self):
        text = "".join(self.input_buf).strip()
        if text:
            self.history.append(text)
        self.history_pos = None
        self.clear_input()
        return text

    def history_prev(self):
        if not self.history:
            return
        if self.history_pos is None:
            self.history_pos = len(self.history)
        self.history_pos = max(0, self.history_pos - 1)
        self.input_buf = list(self.history[self.history_pos])
        self.input_cursor = len(self.input_buf)

    def history_next(self):
        if self.history_pos is None:
            return
        self.history_pos = min(len(self.history), self.history_pos + 1)
        if self.history_pos >= len(self.history):
            self.clear_input()
            self.history_pos = None
        else:
            self.input_buf = list(self.history[self.history_pos])
            self.input_cursor = len(self.input_buf)

    # ── drawing ─────────────────────────────────────────────────────────
    def _put(self, row, col, text, style=""):
        self.frame_lines.append(self._at(row, col) + style + text + RESET)

    def _fill(self, row, col, width, style=""):
        if width <= 0:
            return
        self.frame_lines.append(self._at(row, col) + style + " " * width + RESET)

    def _box(self, top, left, height, width, title="", style=""):
        if height < 2 or width < 4:
            return
        b = "┌" + "─" * (width - 2) + "┐"
        m = "│" + " " * (width - 2) + "│"
        bo = "└" + "─" * (width - 2) + "┘"
        self._put(top, left, b, style + fg(C_BORDER))
        for r in range(1, height - 1):
            self._put(top + r, left, m, style + fg(C_BORDER))
        self._put(top + height - 1, left, bo, style + fg(C_BORDER))
        if title:
            t = " " + truncate(title, width - 6) + " "
            self._put(top, left + 2, t, style + BOLD + fg(C_ACCENT))

    def _text_in(self, top, left, height, width, row, text, style=""):
        """Write one line inside a box, clipped to the inner width."""
        inner = width - 2
        if 0 <= row < height - 2:
            self._put(top + 1 + row, left + 1, truncate(text, inner).ljust(inner), style)

    def begin_frame(self):
        self.frame_lines = []

    def end_frame(self):
        self.frame_lines.append(self._at(self.height, 1))
        self._write("".join(self.frame_lines))

    # ── high-level panes ────────────────────────────────────────────────
    def draw_header(self, title, subtitle="", badges=None):
        w = self.width
        self._fill(1, 1, w, bg(C_PANEL) + fg(C_TEXT))
        t = " " + truncate(title, max(10, w - 40))
        self._put(1, 1, t, bg(C_PANEL) + BOLD + fg(C_ACCENT))
        if subtitle:
            self._put(1, 2 + display_width(t), truncate(subtitle, w - display_width(t) - 4),
                      bg(C_PANEL) + fg(C_DIM))
        if badges:
            x = w
            for label, colour in reversed(badges):
                txt = " " + label + " "
                x -= display_width(txt)
                if x < 1:
                    break
                self._put(1, x, txt, bg(C_PANEL) + BOLD + fg(colour))

    def draw_footer(self, help_text):
        w = self.width
        self._fill(self.height, 1, w, bg(C_PANEL) + fg(C_DIM))
        self._put(self.height, 2, truncate(help_text, w - 3), bg(C_PANEL) + fg(C_DIM))

    def draw_input(self, row, prompt=None, placeholder=None, colour=C_TEXT):
        w = self.width
        p = prompt if prompt is not None else self.input_prompt
        self._fill(row, 1, w, bg(C_BG))
        self._put(row, 1, " " + p, bg(C_BG) + BOLD + fg(C_ACCENT))
        start = 2 + display_width(p)
        avail = w - start - 1
        text = "".join(self.input_buf)
        if not text and placeholder:
            self._put(row, start, truncate(placeholder, avail), bg(C_BG) + DIM + fg(C_DIM))
        else:
            # keep the cursor visible: scroll the buffer horizontally
            before = "".join(self.input_buf[:self.input_cursor])
            bwidth = display_width(before)
            offset = 0
            if bwidth > avail - 1:
                offset = bwidth - (avail - 1)
            shown = text
            # drop characters from the left until it fits the offset
            dropped = 0
            while shown and dropped < offset:
                dropped += wcwidth(shown[0])
                shown = shown[1:]
            self._put(row, start, truncate(shown, avail), bg(C_BG) + fg(colour))
            col = start + (bwidth - offset)
            self._put(row, max(1, min(col, w)), "", bg(C_BG))

    def draw_messages(self, top, left, height, width, empty_hint="No messages yet."):
        inner_w = width - 2
        inner_h = height - 2
        if inner_h <= 0 or inner_w <= 0:
            return
        # Build wrapped lines from the tail of the message list.
        rendered = []
        for m in self.messages:
            kind = m.get("kind", "msg")
            if kind == "msg":
                prefix = "  "
                who = m.get("nick", "?")
                stamp = m.get("time", "")
                head = "%s %s" % (who, stamp)
                body_lines = wrap(m.get("text", ""), max(10, inner_w - len(prefix)))
                first = True
                for i, line in enumerate(body_lines):
                    if first:
                        rendered.append({
                            "kind": "msg",
                            "head": head,
                            "text": line,
                            "prefix": prefix,
                            "mine": m.get("mine", False),
                            "nick": who,
                        })
                        first = False
                    else:
                        rendered.append({
                            "kind": "cont", "text": line,
                            "prefix": prefix, "mine": m.get("mine", False),
                            "nick": who,
                        })
            else:
                for line in wrap(m.get("text", ""), inner_w - 2):
                    rendered.append({"kind": kind, "text": line})

        total = len(rendered)
        max_scroll = max(0, total - inner_h)
        self.scroll = max(0, min(self.scroll, max_scroll))
        start = max(0, total - inner_h - self.scroll)
        window = rendered[start:start + inner_h]

        if not total:
            self._text_in(top, left, height, width, 0, empty_hint, DIM + fg(C_DIM))
            return

        for row in range(inner_h):
            if row >= len(window):
                break
            item = window[row]
            kind = item["kind"]
            if kind == "msg":
                nick = truncate(item["nick"], 18)
                colour = C_WARN if item["mine"] else C_ACCENT
                head = item["head"]
                text = item["text"]
                avail = inner_w - display_width(head) - 2
                line = nick + " " + truncate(text, max(4, avail))
                self._text_in(top, left, height, width, row,
                              " " + truncate(head, inner_w - 1), BOLD + fg(colour))
                # Overwrite with the body on the same row, after the header.
                hx = left + 1 + display_width(head) + 1
                self._put(top + 1 + row, hx,
                          truncate(text, max(1, left + width - 1 - hx)),
                          fg(C_TEXT))
            elif kind == "cont":
                self._text_in(top, left, height, width, row, "    " + item["text"], fg(C_TEXT))
            elif kind == "sys":
                self._text_in(top, left, height, width, row,
                              "  " + item["text"], ITALIC + fg(C_SYS))
            elif kind == "err":
                self._text_in(top, left, height, width, row,
                              "  " + item["text"], fg(C_ERR))
            elif kind == "join":
                self._text_in(top, left, height, width, row,
                              "  " + item["text"], DIM + fg(C_ACCENT))
            elif kind == "sep":
                self._text_in(top, left, height, width, row,
                              "  " + item["text"], DIM + fg(C_DIM))

        if self.scroll:
            indicator = " ↑ %d more " % self.scroll
            self._put(top, left + width - display_width(indicator) - 2,
                      indicator, bg(C_PANEL) + fg(C_WARN))

    def draw_room_list(self, top, left, height, width, rooms, selected=0,
                       title="Rooms", query=""):
        self._box(top, left, height, width, title)
        inner_h = height - 2
        inner_w = width - 3
        if not rooms:
            self._text_in(top, left, height, width, 0,
                          "no rooms yet — press n to create one", DIM + fg(C_DIM))
            return
        # scroll window so the selection is visible
        first = 0
        if selected >= inner_h:
            first = selected - inner_h + 1
        for i in range(inner_h):
            idx = first + i
            if idx >= len(rooms):
                break
            r = rooms[idx]
            sel = idx == selected
            style = (bg(C_SEL) + BOLD + fg(C_ACCENT)) if sel else fg(C_TEXT)
            marker = "▸ " if sel else "  "
            users = r.get("users", 0)
            name = truncate(r.get("name", "?"), max(6, inner_w - 10))
            count = "%2d" % users
            gap = max(1, inner_w - display_width(marker) - display_width(name) - len(count) - 1)
            line = marker + name + " " * gap + count
            self._put(top + 1 + i, left + 1, line.ljust(inner_w), style)
            if sel:
                topic = r.get("topic") or ""
                ttl = r.get("ttl")
                if topic or ttl:
                    extra = topic if topic else ""
                    if ttl is not None:
                        mins = int(ttl) // 60
                        extra = (extra + "  " if extra else "") + "⏳ %dm" % mins
                    self._put(top + 2 + i if False else top + 1 + i,
                              left + 1, " " * inner_w, bg(C_SEL))
                    self._put(top + 1 + i, left + 1,
                              line.ljust(inner_w), style)

    def draw_help_panel(self, top, left, height, width, lines):
        self._box(top, left, height, width, "Keys")
        for i, (key, desc) in enumerate(lines[:height - 2]):
            self._text_in(top, left, height, width, i, "", "")
            self._put(top + 1 + i, left + 2, truncate(key, 12), BOLD + fg(C_ACCENT2))
            self._put(top + 1 + i, left + 15, truncate(desc, width - 17), fg(C_DIM))

    def draw_status(self, row, left_text, right_text="", colour=C_DIM):
        w = self.width
        self._fill(row, 1, w, bg(C_PANEL))
        self._put(row, 2, truncate(left_text, w - 4), bg(C_PANEL) + fg(colour))
        if right_text:
            x = w - display_width(right_text) - 1
            if x > 1:
                self._put(row, x, right_text, bg(C_PANEL) + fg(C_DIM))

    def draw_bar(self, row, value, maximum, width, colour=C_ACCENT, label=""):
        width = max(4, width)
        filled = 0 if not maximum else int(round(width * min(1.0, value / maximum)))
        bar = "█" * filled + "░" * (width - filled)
        self._put(row, 2, truncate(label + " " + bar, self.width - 3), fg(colour))
