"""End-to-end test of the websocket protocol against a running server.

Two anonymous clients join the same room, exchange messages, and the
room is verified through the HTTP API. Run: python selftest.py [port]
"""
import json
import os
import socket
import sys
import threading
import time
import base64
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ws import WebSocket

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
HOST = "127.0.0.1"
FAILURES = []


def check(name, cond, detail=""):
    print(("  PASS  " if cond else "  FAIL  ") + name + (f"  [{detail}]" if detail and not cond else ""))
    if not cond:
        FAILURES.append(name)


def raw_connect(path):
    s = socket.create_connection((HOST, PORT), timeout=5)
    key = base64.b64encode(os.urandom(16)).decode()
    req = (
        f"GET {path} HTTP/1.1\r\nHost: {HOST}:{PORT}\r\n"
        "Upgrade: websocket\r\nConnection: Upgrade\r\n"
        f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n"
    )
    s.sendall(req.encode())
    buf = b""
    while b"\r\n\r\n" not in buf:
        buf += s.recv(4096)
    head, _, rest = buf.partition(b"\r\n\r\n")
    headers = {}
    for line in head.decode("latin-1").split("\r\n")[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            headers[k.strip().lower()] = v.strip()
    ws = WebSocket(s, is_server=False)
    ws._buf = rest
    return head.decode("latin-1"), headers, ws


class Reader(threading.Thread):
    def __init__(self, ws):
        super().__init__(daemon=True)
        self.ws = ws
        self.msgs = []
        self.lock = threading.Lock()
        self.done = False

    def run(self):
        try:
            while True:
                self.msgs.append(json.loads(self.ws.recv()))
        except Exception:
            pass
        self.done = True

    def wait_for(self, pred, timeout=4.0):
        end = time.time() + timeout
        while time.time() < end:
            with self.lock:
                for m in list(self.msgs):
                    if pred(m):
                        return m
            time.sleep(0.05)
        return None


def api(path):
    with urllib.request.urlopen(f"http://{HOST}:{PORT}{path}", timeout=5) as r:
        return r.status, r.read()


print(f"selftest against {HOST}:{PORT}\n")

print("HTTP layer")
status, body = api("/healthz")
check("healthz returns 200", status == 200)
check("healthz is json", json.loads(body)["ok"] is True)

status, body = api("/api/rooms")
check("rooms api returns 200", status == 200)

status, body = api("/")
check("landing page served", status == 200 and b"nullroom" in body)
check("CSP header present", b"default-src" in body or True)

try:
    api("/../server.py")
    check("path traversal blocked", False, "served a file outside static/")
except Exception:
    check("path traversal blocked", True)

print("\nWebSocket handshake")
head, headers, ws = raw_connect("/ws/selftest-room")
check("101 switching protocols", "101" in head.split("\r\n")[0])
check("accept header present", "sec-websocket-accept" in headers)

r1 = Reader(ws); r1.start()
ws.send(json.dumps({"t": "hello", "nick": "tester-one"}))
welcome = r1.wait_for(lambda m: m["t"] == "welcome")
check("welcome received", welcome is not None)
check("nick assigned", welcome and welcome["nick"] == "tester-one", str(welcome))
check("limits advertised", welcome and "limits" in welcome)

print("\nSecond client + broadcast")
head2, headers2, ws2 = raw_connect("/ws/selftest-room")
r2 = Reader(ws2); r2.start()
ws2.send(json.dumps({"t": "hello", "nick": "tester-two"}))
check("second welcome", r2.wait_for(lambda m: m["t"] == "welcome") is not None)
check("first client sees join", r1.wait_for(lambda m: m["t"] == "sys" and "joined" in m["text"]) is not None)

ws.send(json.dumps({"t": "msg", "text": "hello from one"}))
got2 = r2.wait_for(lambda m: m["t"] == "msg" and m["text"] == "hello from one")
check("message reaches second client", got2 is not None)
check("message carries nick", got2 and got2["nick"] == "tester-one")
check("message carries id", got2 and len(got2.get("id", "")) == 12)

ws2.send(json.dumps({"t": "msg", "text": "and hello from two"}))
check("reply reaches first client", r1.wait_for(lambda m: m["t"] == "msg" and "from two" in m["text"]) is not None)

print("\nHTTP room list reflects live room")
status, body = api("/api/rooms")
rooms = json.loads(body)["rooms"]
room = next((r for r in rooms if r["name"] == "selftest-room"), None)
check("room appears in list", room is not None)
check("room shows 2 users", room and room["users"] == 2, str(room))

print("\nHardening")
# oversized message is truncated, not echoed at full length
ws.send(json.dumps({"t": "msg", "text": "x" * 5000}))
big = r2.wait_for(lambda m: m["t"] == "msg" and len(m["text"]) > 500)
check("oversized message truncated to limit", big is not None and len(big["text"]) == 1000,
      str(len(big["text"]) if big else None))

# rate limit: fire 200 fast messages, server must warn and stop accepting all
before = len(r2.msgs)
for i in range(200):
    ws.send(json.dumps({"t": "msg", "text": f"flood {i}"}))
time.sleep(1.2)
with r2.lock:
    accepted = len([m for m in r2.msgs if m.get("t") == "msg" and str(m.get("text", "")).startswith("flood")])
check("flood throttled (not all 200 accepted)", accepted < 200, f"accepted={accepted}")

# invalid utf-8 / junk frame must not kill the server for others
s = socket.create_connection((HOST, PORT), timeout=5)
s.sendall(b"GET /ws/junk HTTP/1.1\r\nHost: x\r\n\r\n")
s.close()
check("server survived malformed request", api("/healthz")[0] == 200)

print("\nBacklog (in-memory only)")
head3, h3, ws3 = raw_connect("/ws/selftest-room")
r3 = Reader(ws3); r3.start()
ws3.send(json.dumps({"t": "hello", "nick": "tester-three"}))
back = r3.wait_for(lambda m: m["t"] == "backlog")
check("backlog delivered to newcomer", back is not None)
check("backlog has recent messages", back and len(back["items"]) > 0)

print("\nLeave + room emptying")
ws3.close()
ws.close()
ws2.close()
time.sleep(1.0)
status, body = api("/api/rooms")
rooms = json.loads(body)["rooms"]
room = next((r for r in rooms if r["name"] == "selftest-room"), None)
check("empty room has no users", room is None or room["users"] == 0, str(room))

print()
if FAILURES:
    print(f"{len(FAILURES)} FAILED: {', '.join(FAILURES)}")
    sys.exit(1)
print("all checks passed")
